% This is the master file to reprodue Section 4 of "How Important Are
% Sectoral Shocks." It calls on filter_full, which in turn calls on kfilter
% and factoran_ . The parameters are epsilon_d, epsilon_q, epsilon_m,
% epsilon_x, epsilon_ls, indicator (allow for durable goods), data set
% number, and the number of burn in periods.
 
clear;
results_table=zeros(20,24);
historical_decomposition=zeros(49,6);
counter=0;
cov_ind_output_A=0;
cov_ind_output_B=0;
cov_ind_output_D=0;
cov_model_output_A=0;
cov_model_output_B=0;
cov_model_output_D=0;

% vary eps_M
for em=0.95:-0.05:0.10
    parameters=[0.999, 4/5, em, 0.999, 2,  0, 1, 4]; filter_full;
    parameters=[0.999, 2/5, em, 0.999, 2,  0, 1, 4]; filter_full;
    parameters=[0.999, 0.999, em, 0.999, 2,  0, 1, 4]; filter_full;
    parameters=[0.999, 3/5, em, 0.999, 2,  0, 1, 4]; filter_full;
end

parameters=[0.999, 0.999, 0.999, 0.999, 2,  0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999, 0.999, 2,  0, 1, 4]; filter_full;
parameters=[0.999, 4/5, 0.999, 0.999, 2,  0, 1, 4]; filter_full;
parameters=[0.999, 3/5, 0.999, 0.999, 2,  0, 1, 4]; filter_full;

% vary eps_Q
for eq=0.15:0.10:1.55
    parameters=[0.999, eq, 0.10, 0.999, 2,  0, 1, 4]; filter_full;
    parameters=[0.999, eq, 0.999, 0.999, 2,  0, 1, 4]; filter_full;
end

% vary eps_D
for ed=0.6:0.2:1.8
    if ed~=1
      parameters=[ed, 0.999, 0.999, 0.999 , 2, 0, 1, 4]; filter_full;
      parameters=[ed, 4/5, 0.999, 0.999 , 2, 0, 1, 4]; filter_full;
      parameters=[ed, 3/5, 0.999, 0.999 , 2, 0, 1, 4]; filter_full;
      parameters=[ed, 0.999, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
      parameters=[ed, 4/5, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
      parameters=[ed, 3/5, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
    end
end

% durables
parameters=[0.999, 4/5, 0.999, 0.999, 2,  1, 1, 4]; filter_full;
parameters=[0.999,0.999, 0.999, 0.999, 2,  1, 1, 4]; filter_full;
parameters=[0.999, 0.999, 1/2,  0.999, 2,  1, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999, 2,  1, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.999, 0.999, 2, 1, 1, 4]; filter_full;
parameters=[2/3,  0.999, 1/2,  0.999, 2, 1, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.999, 2, 1, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.999, 0.999, 2, 1, 1, 4]; filter_full;
parameters=[4/3,  0.999, 1/2,  0.999, 2, 1, 1, 4]; filter_full;
parameters=[4/3, 0.999, 0.10, 0.999, 2, 1, 1, 4]; filter_full;
parameters=[0.999,  4/5, 0.10, 0.999, 2, 1, 1, 4]; filter_full;

parameters=[0.999, 4/5, 0.999, 0.999, 2,  2, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999, 0.999, 2,  2, 1, 4]; filter_full;
parameters=[0.999, 0.999, 1/2,  0.999, 2,  2, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999, 2,  2, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.999, 0.999, 2, 2, 1, 4]; filter_full;
parameters=[2/3,  0.999, 1/2,  0.999, 2, 2, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.999, 2, 2, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.999, 0.999, 2, 2, 1, 4]; filter_full;
parameters=[4/3,  0.999, 1/2,  0.999, 2, 2, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 0.999, 2, 2, 1, 4]; filter_full;
parameters=[0.999,  4/5, 0.10, 0.999, 2, 1, 1, 4]; filter_full;

% vary  eps_X

parameters=[0.999, 0.999, 0.999, 1.2 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999, 0.999 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999, 0.8 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999, 0.6 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 1.2 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.8 , 2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.6 , 2, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 1.2 , 2, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.8 , 2, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.6 , 2, 0, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 1.2 , 2, 0, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 0.999 , 2, 0, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 0.8 , 2, 0, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 0.6 , 2, 0, 1, 4]; filter_full;

% vary  eps_LS
parameters=[0.999, 0.999, 0.999,0.999, 1, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.999,0.999, 4, 0, 1, 4]; filter_full;
parameters=[0.999,0.999, 0.999,0.999, 1/2, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999, 1, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999, 4, 0, 1, 4]; filter_full;
parameters=[0.999, 0.999, 0.10, 0.999, 1/2, 0, 1, 4]; filter_full;
parameters=[2/3, 0.999, 0.10, 0.999, 1, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.999, 4, 0, 1, 4]; filter_full;
parameters=[2/3,  0.999, 0.10, 0.999, 1/2, 0, 1, 4]; filter_full;
parameters=[4/3, 0.999, 0.10, 0.999, 1, 0, 1, 4]; filter_full;
parameters=[4/3,  0.999, 0.10, 0.999, 4, 0, 1, 4]; filter_full;
parameters=[4/3, 0.999, 0.10, 0.999, 1/2, 0, 1, 4]; filter_full;

% other samples 
for d_set_idx=1:11
  parameters=[0.999, 4/5, 0.999, 0.999, 2, 0, d_set_idx, 4]; filter_full;   
  parameters=[0.999, 4/5, 0.10, 0.999, 2, 0, d_set_idx, 4]; filter_full;   
  parameters=[0.999,  0.999, 0.999, 0.999, 2, 0, d_set_idx, 4]; filter_full;   
  parameters=[0.999,   0.999, 0.10,  0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[2/3,   0.999, 0.10,  0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[4/3,   0.999, 0.10,  0.999, 2, 0, d_set_idx, 4]; filter_full;
end

for d_set_idx=12:17
  d_set_idx
  parameters=[0.999, 2/3, 0.999, 0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[0.999, 2/3, 1/3, 0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[0.999, 0.999, 0.999, 0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[0.999,  0.999, 1/3,  0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[2/3,  0.999, 1/3,  0.999, 2, 0, d_set_idx, 4]; filter_full;
  parameters=[4/3,  0.999, 1/3,  0.999, 2, 0, d_set_idx, 4]; filter_full;
end

csvwrite('results_table.csv', results_table);
csvwrite('historical_decomposition.csv', historical_decomposition);
csvwrite('historical_decomposition_all_1.csv', historical_decomposition_all_1);
csvwrite('historical_decomposition_all_2.csv', historical_decomposition_all_2);
csvwrite('historical_decomposition_all_3.csv', historical_decomposition_all_3);