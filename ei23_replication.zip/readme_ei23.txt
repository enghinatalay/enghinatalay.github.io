This zip file contains the replication do files for "Time Use Before, During, and After the Pandemic." 

1. Code:

There are two .do files, that should be run in order:

A) read_atus.do : reads in the .dat file that can be downloaded from IPUMS.
B) ei23.do : constructs the table and figures in the paper.

2. Data:

There are two sets of data files to be downloaded:

The google mobility reports can be found at https://www.google.com/covid19/mobility/ 

The American Time Use Survey can be found at https://www.atusdata.org/atus/ . 

The specific extract that I downloaded is given by the following specifications.

SAMPLES:20(hide)
Change
Sample	Note
2003	
2004	
2005	
2006	
2007	
2008	
2009	
2010	
2011	
2012	
2013	
2014	
2015	
2016	
2017	
2018	
2019	
2020	
2021	
2022	

VARIABLES:128(hide)
Change
Type	Variable	Label
H	RECTYPE	Record Type
H	YEAR	Survey year
H	CASEID	ATUS Case ID
H	SERIAL	Household serial number
H	HRHHID_CPS8	Household ID (CPS)
H	YEAR_CPS8	Year of final CPS interview
H	MONTH_CPS8	Month of final CPS interview
H	REGION	Region
H	STATEFIP	FIPS State Code
H	METRO	Metropolitan/central city status
H	MSASIZE	MSA/PMSA size
H	METAREA	Consolidated MSA name
H	COUNTY	FIPS County code
H	FAMINCOME	Family income
H	HH_SIZE	Number of people in household
H	HH_NUMKIDS	Number of children under 18 in household
H	HOUSETYPE	Type of housing unit
H	FAMBUS	Business or farm owned by household member
H	FAMBUS_RESP	Business or farm owned by respondent
P	PERNUM	Person number (general)
P	LINENO	Person line number
P	LINENO_CPS8	Person line number (CPS)
P	MONTH	Month of ATUS interview
P	DAY	ATUS interview day of the week
P	HOLIDAY	Day of ATUS interview was a holiday
P	DATE	Date of ATUS interview
P	WT06	Person weight, 2006 methodology
P	WT20	Person weight, 2020 methodology
P	AGE	Age
P	SEX	Sex
P	RACE	Race
P	HISPAN	Hispanic origin
P	MARST	Marital status
P	YRIMMIG	Year of immigration
P	CITIZEN	Citizenship status
P	BPL	Birthplace
P	AGE_CPS8	Age (CPS)
P	SEX_CPS8	Sex (CPS)
P	EDUC	Highest level of school completed
P	SCHLCOLL_CPS8	Enrollment in school or college (CPS)
P	VETSTAT	Veteran status
P	AFNOW	Current serving in Armed Forces
P	EMPSTAT	Labor force status
P	MULTJOBS	Has more than one job
P	OCC2	General occupation category, main job
P	OCC	Detailed occupation category, main job
P	IND	Detailed industry classification, main job
P	FAMBUS_PAY	Received pay or profits from family business
P	LOOKING	Looking for work during last 4 weeks
P	RETIRED	Retired
P	EMPSTAT_CPS8	Labor force status (CPS)
P	OCC2_CPS8	General occupation category, main job (CPS)
P	OCC_CPS8	Detailed occupation category, main job (CPS)
P	RETIRED_CPS8	Retired (CPS)
P	FULLPART	Full time/part time employment status
P	UHRSWORKT	Hours usually worked per week
P	EARNWEEK	Weekly earnings
P	PAIDHOUR	Hourly or non-hourly pay
P	HOURWAGE	Hourly earnings
P	HRSATRATE	Hours worked at hourly rate
P	OTUSUAL	Usually receives overtime, tips, commission at main job
P	OTPAY	Weekly overtime earnings
P	KIDUND18	Own child under 18 in household
P	HH_NUMOWNKIDS	Number of own children under 18 in household
P	KIDUND13	Own child under 13 in household
P	KIDUND1	Own child under 1 in household
P	KID1TO2	Own child age 1 to 2 in household
P	KID3TO5	Own child age 3 to 5 in household
P	KID6TO12	Own child age 6 to 12 in household
P	KID13TO17	Own child age 13 to 17 in household
P	NOSCCRSN1	Reason no secondary childcare of own household children
P	NOSCCRSN2	Reason no secondary childcare of non-own household children
P	SCC_ALL	Total time spent on secondary childcare for all children
P	SCC_OWN	Total time spent on secondary childcare of own children
P	SCC_HH	Total time spent on secondary childcare for hh children
P	SCC_HHNHHOWN	Total time spent on secondary childcare for hh and own non-hh children
P	SCC_OWNHH	Total time spent on secondary childcare of own hh children
P	SCC_OWNNHH	Total time spent on secondary childcare of own non-hh children
P	SCC_NOWNHH	Total time spent on secondary childcare of non-own hh children
P	SCC_NOWNNHH	Total time spent on secondary childcare of non-own, non-hh children
P	DIFFANY	Any difficulty
P	DATAQUAL	Interview should not be used
P	CPSIDP	Unique Longitudinal CPS Identifier
P	WB_RESP	Well-Being Module Respondent
P	RESTED	Well-rested yesterday
P	HIGHBP	High blood pressure in last five years
P	WBELIGTIME	Minutes spent in well-being module eligible activities
P	PAINMED	Pain medication yesterday
P	WBTYPICAL	Yesterday was typical
P	WBLADDER	Life satisfaction ladder
P	COVIDTELEW	Worked remotely for pay due to COVID-19 pandemic (CPS)
P	COVIDPAID	Received pay for hours not worked due to the COVID-19 pandemic (CPS)
P	COVIDUNAW	Unable to work due to COVID-19 pandemic (CPS)
P	COVIDLOOK	Prevented from looking for work due to COVID-19 pandemic (CPS)
P	COVIDMED	Did not get needed medical care for condition other than COVID-19 due to the COVID-19 pandemic (CPS)
A	ACTLINE	Activity line number
A	ACTIVITY	Activity
A	WHERE	Location of activity
A	DURATION_EXT	Duration of activity (extended version)
A	DURATION	Duration of activity
A	METVALUE	Metabolic equivalent (MET) value for activity codes
A	SCC_HHNHHOWN_LN	Time spent during activity on secondary child care of household and own, non-household children
A	SCC_ALL_LN	Time spent during activity on secondary child care of all children
A	SCC_NOWNNHH_LN	Time spent during activity on secondary child care of non-own, non-household children
A	SCC_HH_LN	Time spent during activity on secondary child care of household children
A	SCC_NOWNHH_LN	Time spent during activity on secondary child care of non-own, household children
A	SCC_OWN_LN	Time spent during activity on secondary child care of own children
A	SCC_OWNHH_LN	Time spent during activity on secondary child care of own, household children
A	SCC_OWNNHH_LN	Time spent during activity on secondary child care of own, non-household children
A	SEC_ALL_LN	Time spent during activity on secondary eldercare for household and non-household members
A	WHO_ASK	Who asked for activity
A	START	Activity start time
A	STOP	Activity stop time
A	SCPAIN	Pain scale
A	SCHAPPY	Happiness scale
A	SCSAD	Sadness scale
A	SCTIRED	Fatigue scale
A	SCSTRESS	Stress scale
A	INTERACT	Interacting during activity
A	MEANING	Meaningfulness scale
A	AWBWT	Well-being Module final statistical weight, activity-level
W	ACTLINEW	Activity line number
W	LINENOW	Person line number
W	WHOLINE	Number of the who record for this episode
W	RELATEW	Relationship of person with whom activity was done
W	RELATEWU	Relationship of person with whom activity was done (uncollapsed version)
W	AGEW	Age of person with whom activity was done
W	SEXW	Sex of person with whom activity was done

TIME USE VARIABLES:101(hide)
Change
Time Use Variable	Label
ACT_CAREHH	ACT: Caring for and helping household members
ACT_CARENHH	ACT: Caring for and helping non-household members
ACT_EDUC	ACT: Educational activities
ACT_FOOD	ACT: Eat and drinking
ACT_GOVSERV	ACT: Government services and civic obligations
ACT_HHACT	ACT: Household activities
ACT_HHSERV	ACT: Household services
ACT_PCARE	ACT: Personal care
ACT_PHONE	ACT: Telephone calls
ACT_PROFSERV	ACT: Professional and personal care services
ACT_PURCH	ACT: Consumer purchases
ACT_SOCIAL	ACT: Socializing, relaxing, and leisure
ACT_SPORTS	ACT: Sports, exercise, and recreation
ACT_TRAVEL	ACT: Traveling
ACT_VOL	ACT: Volunteer activities
ACT_WORK	ACT: Working and Work-related Activities
BLS_CAREHH	BLS: Caring for and helping household members
BLS_CAREHH_ADULT	BLS: Caring for and helping household members: Caring for and helping household adults
BLS_CAREHH_KID	BLS: Caring for and helping household members: Caring for and helping household children
BLS_CAREHH_KIDEDUC	BLS: Caring for and helping household members: Activities related to household children's education
BLS_CAREHH_KIDHEALTH	BLS: Caring for and helping household members: Activities related to household children's health
BLS_CAREHH_KIDOTHER	BLS: Caring for and helping household members: Caring for and helping household children (except activities related to education and health)
BLS_CAREHH_TRAVEL	BLS: Caring for and helping household members: Travel related to caring for and helping household members
BLS_CARENHH	BLS: Caring for and helping non-household members
BLS_CARENHH_ADULT	BLS: Caring for and helping non-household members: Caring for and helping non-household adults
BLS_CARENHH_ADULTCARE	BLS: Caring for and helping non-household members: Caring for non-household adults
BLS_CARENHH_ADULTHELP	BLS: Caring for and helping non-household members: Helping non-household adults
BLS_CARENHH_KID	BLS: Caring for and helping non-household members: Caring for and helping non-household children
BLS_CARENHH_TRAVEL	BLS: Caring for and helping non-household members: Travel related to caring for and helping non-household members
BLS_COMM	BLS: Telephone calls, mail, and e-mail
BLS_COMM_MSG	BLS: Telephone calls, mail, and e-mail: Household and personal messages
BLS_COMM_MSGEMAIL	BLS: Telephone calls, mail, and e-mail: Household and personal e-mail and messages
BLS_COMM_MSGMAIL	BLS: Telephone calls, mail, and e-mail: Household and personal mail and messages
BLS_COMM_TELE	BLS: Telephone calls, mail, and e-mail: Telephone calls (to or from)
BLS_COMM_TRAVEL	BLS: Telephone calls, mail, and e-mail: Travel related to telephone calls
BLS_EDUC	BLS: Educational activities
BLS_EDUC_CLASS	BLS: Educational activities: Attending class
BLS_EDUC_HWORK	BLS: Educational activities: Homework and research
BLS_EDUC_TRAVEL	BLS: Educational activities: Travel related to education
BLS_FOOD	BLS: Eat and drinking
BLS_FOOD_FOOD	BLS: Eat and drinking: Eating and drinking
BLS_FOOD_TRAVEL	BLS: Eating and drinking: Travel related to eating and drinking
BLS_HHACT	BLS: Household activities
BLS_HHACT_EXTER	BLS: Household activities: Exterior maintenance, repair, and decoration
BLS_HHACT_FOOD	BLS: Household activities: Food preparation and cleanup
BLS_HHACT_HHMGMT	BLS: Household activities: Household management
BLS_HHACT_HWORK	BLS: Household activities: Housework
BLS_HHACT_INTER	BLS: Household activities: Interior maintenance, repair, and decoration
BLS_HHACT_LAWN	BLS: Household activities: Lawn and garden care
BLS_HHACT_PET	BLS: Household activities: Animals and pets
BLS_HHACT_TOOL	BLS: Household activities: Appliances, tools, and toys
BLS_HHACT_TRAVEL	BLS: Household activities: Travel related to household activities
BLS_HHACT_VEHIC	BLS: Household activities: Vehicles
BLS_LEIS	BLS: Leisure and sports
BLS_LEIS_ARTS	BLS: Leisure and sports: Arts and entertainment (other than sports)
BLS_LEIS_ATTEND	BLS: Leisure and sports: Attending or hosting social events
BLS_LEIS_ATTSPORT	BLS: Leisure and sports: Attending sporting or recreational events
BLS_LEIS_PARTSPORT	BLS: Leisure and sports: Participating in sports, exercise, and recreation
BLS_LEIS_RELAX	BLS: Leisure and sports: Relaxing and leisure
BLS_LEIS_SOC	BLS: Leisure and sports: Socializing, relaxing, and leisure
BLS_LEIS_SOCCOM	BLS: Leisure and sports: Socializing and communicating
BLS_LEIS_SOCCOMEX	BLS: Leisure and sports: Socializing and communicating (except social events)
BLS_LEIS_SPORT	BLS: Leisure and sports: Sports, exercise, and recreation
BLS_LEIS_TRAVEL	BLS: Leisure and sports: Travel related to leisure and sports
BLS_LEIS_TV	BLS: Leisure and sports: Watching TV
BLS_OTHER	BLS: Other activities not elsewhere classified
BLS_PCARE	BLS: Personal care
BLS_PCARE_ACT	BLS: Personal care: Personal activities
BLS_PCARE_GROOM	BLS: Personal care: Grooming
BLS_PCARE_HEALTH	BLS: Personal care: Health-related self care
BLS_PCARE_SLEEP	BLS: Personal care: Sleeping
BLS_PCARE_TRAVEL	BLS: Personal care: Travel related to personal care
BLS_PURCH	BLS: Purchasing goods and services
BLS_PURCH_BANK	BLS: Purchasing goods and services: Financial services and banking
BLS_PURCH_CONS	BLS: Purchasing goods and services: Consumer goods purchases
BLS_PURCH_GOV	BLS: Purchasing goods and services: Government services
BLS_PURCH_GROC	BLS: Purchasing goods and services: Grocery shopping
BLS_PURCH_HEALTH	BLS: Purchasing goods and services: Medical and care services
BLS_PURCH_HHSERV	BLS: Purchasing goods and services: Household services
BLS_PURCH_HOME	BLS: Purchasing goods and services: Home maintenance, repair, decoration, and construction (not done by self)
BLS_PURCH_PCARE	BLS: Purchasing goods and services: Personal care services
BLS_PURCH_PROF	BLS: Purchasing goods and services: Professional and personal care services
BLS_PURCH_TRAVEL	BLS: Purchasing goods and services: Travel related to purchasing goods and services
BLS_PURCH_VEHIC	BLS: Purchasing goods and services: Vehicle maintenance and repair services (not done by self)
BLS_SOCIAL	BLS: Organizational, civic, and religious activities
BLS_SOCIAL_ADMIN	BLS: Organizational, civic, and religious activities: Administrative and support activities
BLS_SOCIAL_ATTEND	BLS: Organizational, civic, and religious activities: Attending meetings, conferences, and training
BLS_SOCIAL_CIVIC	BLS: Organizational, civic, and religious activities: Civic obligations and participation
BLS_SOCIAL_CULTURE	BLS: Organizational, civic, and religious activities: Participating in performance and cultural activities
BLS_SOCIAL_MAINTEN	BLS: Organizational, civic, and religious activities: Indoor and outdoor maintenance, building, and cleanup activities
BLS_SOCIAL_RELIG	BLS: Organizational, civic, and religious activities: Religious and spiritual activities
BLS_SOCIAL_SOCSERV	BLS: Organizational, civic, and religious activities: Social service and care activities (except medical)
BLS_SOCIAL_TRAVEL	BLS: Organizational, civic, and religious activities: Travel related to organizational, civic, and religious activities
BLS_SOCIAL_VOL	BLS: Organizational, civic, and religious activities: Volunteering (organizational and civic activities)
BLS_SOCIAL_VOLACT	BLS: Organizational, civic, and religious activities: Volunteer activities
BLS_WORK	BLS: Working and work-related activities
BLS_WORK_OTHER	BLS: Working and work-related activities: Other income-generating activities
BLS_WORK_SEARCH	BLS: Working and work-related activities: Job search and interviewing
BLS_WORK_TRAVEL	BLS: Working and work-related activities: Travel related to work
BLS_WORK_WORKING	BLS: Working and work-related activities: Working
BLS_WORK_WORKREL	BLS: Working and work-related activities: Work-related activities

DATA FORMAT:.dat (fixed-width text) 
Change
STRUCTURE:Hierarchical 
Change
SAMPLE MEMBERS:Respondents
Change