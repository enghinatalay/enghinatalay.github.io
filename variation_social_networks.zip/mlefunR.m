
%% This Piece of code computes the log-likelood of the base JR model (using info on nodes' ages).  It is used in combination 
%% with fminsearch to find the MLE of the base JR model (using info on nodes' ages).

function f=mlefun(par, A)

mr=par(1);
r=par(2);

combos=unique(A, 'rows');
combos=[combos zeros(length(combos),1)];
for it=1:length(combos)
  combos(it,3)=sum(A(:,1)==combos(it,1) & A(:,2)==combos(it,2));
end


prob=zeros(length(combos),1);
for it=1:length(combos)
  qq=combos(it,1); 
  aa=combos(it,2);
prob(it)=gammaln(exp(mr)+qq)-gammaln(exp(mr))-gammaln(qq+1)+(exp(mr)/(1+exp(r)))*log(aa)+qq*log(1-aa^(1/(1+exp(r))));
end

[mr r  sum(prob.*combos(:,3))/1e3]
f=-sum(prob.*combos(:,3));




