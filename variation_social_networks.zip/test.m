A=csvread('formle.csv',1,0);
A1=zeros(1,8);
iter=0
csvwrite('iter5.csv',iter);
mJA=1.86*10^(17);
rJA=2.05*10^(-17);
lr=zeros(137,2);
ages=unique(A(:,2))

lr(1,1)=mlefunR([log(mJA)+log(rJA) log(rJA)], A);
for xx=1:136
   xx
   AS=A((A(:,2)==ages(xx)),:);
   lr(xx+1,1)=mlefunR([log(mJA)+log(rJA) log(rJA)], AS);
end

iter=0
num=1
m0=2169.39;
r0=1.121;
a0=.491;
b0=28.121;

lr(1,2)=mlefunpb([log(m0) log(r0) a0/(a0+b0) b0], A,2);
for xx=1:136
   xx
   AS=A((A(:,2)==ages(xx)),:);
  lr(xx+1,2)=mlefunpb([log(m0) log(r0) a0/(a0+b0) b0], AS,2);
end
csvwrite('teststats.csv', lr)


