function fq  = pbarfun(par2,num)

  %% This piece of code computes pbar, according to equation 10. 
  %% To solve for pbar we look for a fixed point.  A while loop runs 
  %% until a given equation switches sign.  The pbar for which
  %% the switch occurs is then returned to mlefunpb.m (which is the m file 
  %% that called pbarfun)
  %% Note that, to save time, pbar is not 
  %% computed every iteration of the simulated annealing algorithm.   


a=par2(3);
b=par2(4);
r=par2(2);
m=par2(1);

if num==1
  iter=csvread('iter1.csv');
elseif num==2
  iter=csvread('iter2.csv');
elseif num==3
  iter=csvread('iter3.csv');
elseif num==4
  iter=csvread('iter4.csv');
 else 
  iter=csvread('iter5.csv');
end

if iter<500
  pbar=floor(a/(a+b)*1000)/1000;
end
if iter>=500
  if num==1
    pbar=csvread('pbar1.csv')-.03;
  elseif num==2
    pbar=csvread('pbar2.csv')-.03;
  elseif num==3
    pbar=csvread('pbar3.csv')-.03;
  elseif num==4
    pbar=a/(a+b);
  else 
    pbar=a/(a+b);
  end
end

diff=1;

bins1=15000;
bins2=500;

qq=ones(bins2-1,1)*(0:bins1);
pp=((1:(bins2-1))/bins2)'*ones(1,bins1+1);

while diff>0 
diff= sum(sum((1+r)*pbar./pp.*exp(-gammaln(m*r*pbar)-gammaln(m*r*pbar+(r+1)*pbar./pp+qq+1)+gammaln(m*r*pbar+(r+1)*pbar./pp)+gammaln(m*r*pbar+qq)+gammaln(a+b)-gammaln(a)-gammaln(b)+(a-1)*log(pp)+(b-1)*log(1-pp)).*qq))/(bins2-1)-pbar*m;

pbar=pbar+1/1000;

end

fq=pbar;
