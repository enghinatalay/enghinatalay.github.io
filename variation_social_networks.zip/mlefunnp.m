function f=mlefunpb(par, A,num)

%% This piece of code is called by anneal.m 
%% During each iteration mlefunpb computes the 
%% log-likelihood of the extended Jackson-Rogers model
%% where p is drawn from a "nonparametric distribution"

m=par(1);
r=par(2);

ff=[par(3) par(4) par(5) par(6) par(7) par(8) par(9) par(10) par(11) par(12) par(13) par(14) par(15) par(16) par(17)];
ff2=[par(18) par(19) par(20) par(21) par(22)  par(23) par(24) par(25) par(26) par(27) par(28) par(29) par(30) par(31)];
ff3=[par(32) par(33) par(34) par(35) par(36) par(37) par(38) par(39) par(40) par(41) par(42) par(43) par(44) par(45)];
ff4=[par(46) par(47) par(48) par(49) par(50) par(51) par(52) par(53) par(54) par(55) par(56) par(57) par(58) par(59)];
ff5=[par(60) par(61) par(62) par(63) par(64) par(65) par(66) par(67) par(68) par(69) par(70) par(71) par(72) par(73)];
ff6=[par(74) par(75) par(76) par(77) par(78) par(79) par(80) par(81) par(82) par(83) par(84) par(85) par(86) par(87)];
ff7=[par(88) par(89) par(90) par(91) par(92) par(93) par(94) par(95) par(96) par(97) par(98) par(99) par(100) par(101) par(102)];
ff=horzcat(ff,ff2);
ff=horzcat(ff,ff3);
ff=horzcat(ff,ff4);
ff=horzcat(ff,ff5);
ff=horzcat(ff,ff6);
ff=horzcat(ff,ff7);
ff=exp(ff);
ff=ff/sum(ff)*length(ff);

if num==1
  iter=csvread('iter1.csv');
  iter=iter+1;
  csvwrite('iter1.csv', iter);
elseif num==2
  iter=csvread('iter2.csv');
  iter=iter+1;
  csvwrite('iter2.csv', iter);
elseif num==3
  iter=csvread('iter3.csv');
  iter=iter+1;
  csvwrite('iter3.csv', iter);
elseif num==4
  iter=csvread('iter4.csv');
  iter=iter+1;
  csvwrite('iter4.csv', iter);
else
  iter=csvread('iter5.csv');
  iter=iter+1;
  csvwrite('iter5.csv', iter);
end

if mod(iter,1)==0
  pbar=pbarfunnp([exp(m) exp(r)],  ff,num);
  if num==1
  csvwrite('pbar1.csv', pbar);
  elseif num==2
  csvwrite('pbar2.csv', pbar);
  elseif num==3
  csvwrite('pbar3.csv', pbar);
  elseif num==4
  csvwrite('pbar4.csv', pbar);
  else 
  csvwrite('pbar5.csv', pbar);
  end

else 
  if num==1 
    pbar=csvread('pbar1.csv');
  elseif num==2
    pbar=csvread('pbar2.csv');
  elseif num==3
    pbar=csvread('pbar3.csv');
  elseif num==4
    pbar=csvread('pbar4.csv');
  else 
    pbar=csvread('pbar5.csv');
  end
end

bins=5e3;  %% Bins is the number of possible values of p 

gg=(bins)/length(ff);
ffbins=kron(ff,ones(1,gg));

combos=unique(A, 'rows');
combos=[combos zeros(length(combos),1)];

for it=1:length(combos)
  combos(it,3)=sum(A(:,1)==combos(it,1) & A(:,2)==combos(it,2));
end

prob=zeros(length(combos),1);
for it=1:length(combos)
  qq=combos(it,1); 
  aa=combos(it,2);
  xy=(1:(bins))/bins-1/2/bins;
  aq=sum(exp(-log(bins)+qq*log(1-aa.^(xy/pbar/(1+exp(r))))+  log(ffbins) + (exp(m+r)*xy/(1+exp(r)))*log(aa)));
  prob(it)=(log(aq)+gammaln(pbar*exp(m+r)+qq)-gammaln(pbar*exp(m+r))-gammaln(qq+1) );
end

rrrr=clock;
tim=rrrr(4)+rrrr(5)/60+rrrr(6)/60/60;
[iter/100 tim pbar m  r round(log(ff)*10)/10  sum(prob.*combos(:,3))/1e3]
f=-sum(prob.*combos(:,3));
