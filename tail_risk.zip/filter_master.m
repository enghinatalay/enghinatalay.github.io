% This is the master file to reprodue Section 4 of "Accounting for the Sources 
% of Macroeconomic Tail Risks." It calls on filter_, which in turn calls on kfilter
% and factoran_ . Here we loop over the values of epsilon. The second option is the 
% burn_in period, which we set as three years.

clear;

result_table = zeros(13,13);
counter=0;
for em = 0.999:(-.10):0.099
    parameters = [ em , 12]; filter_;
end
csvwrite('results_table.csv', results_table)