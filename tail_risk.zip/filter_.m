% This file is called by filter_master.m and computes the correlation of
% productivity shocks, the fraction of aggregate variation that is caused
% by common shocks, and historical decompositions. It calls kfilter.m and
% factoran_.m .  It uses the data that are produced by io_read.do and
% io_read_foreign.do 

delta_K=0.025;
var_beta=0.99;

counter=counter+1;
% These names are taken from "How Important Are Sectoral Shocks" 
% eps_D : elasticity of substitution in consumers' preferences across products
% eps_Q : production EoS between value added and intermeidate inputs
% eps_M (called epsilon in the current paper) : EoS across intermediate inputs 
%  produced by different industries
% eps_X: EoS across investment products produced by different industries
% eps_LS: Labor supply elasticity
eps_D=0.999;  
eps_Q=0.999;
eps_M=parameters(1);
eps_X=0.999;

eps_LS=2;
burn_in=parameters(2);

gamma_K=csvread('data_KJ1997.csv');
gamma_M=csvread('data_MJ1997.csv');
data_O=csvread('data_OJ1997.csv');
data_time=csvread('ioJ_data_linear.csv',1,1);
% McGrattan and Schmitz Correction, to account for unmeasured reapir of capital goods
gamma_K=gamma_K*0.65+eye(length(gamma_K))*0.35;  

data_aggregate = data_time(:,end);
data_time=data_time(:,1:end-1);

gamma_M=gamma_M./repmat(sum(gamma_M), length(gamma_M),1);
gamma_K=gamma_K./repmat(sum(gamma_K), length(gamma_K),1);
mu_vector=data_O(:,3); 

gamma_M_data=gamma_M;
gamma_K_data=gamma_K;
mu_vector_data=mu_vector;

industries=length(gamma_M);
% set the minimum values of the preference vector to be some posit ive but 
% small value, to improve the numerical performance of the filter.
xi_vector=max(6e-3,data_O(:,4));
xi_vector_data=xi_vector/sum(xi_vector);

data_sales_dt=data_time(:,1:industries);
alpha_vector=data_O(:,2)./(data_O(:,1)+data_O(:,2));
I_N=eye(industries);
eps_Q=eps_Q*I_N;
beta_tilde= 1-var_beta*(1-delta_K);
tilde_gamma_M=zeros(industries);
tilde_gamma_X=zeros(industries);
t_S_M_Q=zeros(industries,industries^2);
t_S_X_Q=zeros(industries,industries^2);
T_1 = kron(ones(industries,1), speye(industries));
T_2 = kron(speye(industries), ones(industries,1));

% this portion of code computes the steady state allocation.
% It follows a fixed point algorithm, terminating at the point at which 
% the price vector clears each industry's market clearing condition.

diff_calibrate=1;
while diff_calibrate>1e-3
    price_vector=ones(industries,1);
    gamma_K_old=gamma_K;
    gamma_M_old=gamma_M;
    mu_vector_old=mu_vector;
    diff=price_vector;
    while max(abs(diff))>1e-7
        new_price_vector=((1-mu_vector).*(1/var_beta-(1-delta_K)).^(alpha_vector.*(1-diag(eps_Q)))...
            .*(gamma_K'*(price_vector.^(1-eps_X))).^(alpha_vector.*(1-diag(eps_Q))/(1-eps_X)) ...
             + mu_vector.*(gamma_M'*(price_vector.^(1-eps_M))).^((1-diag(eps_Q))/(1-eps_M))).^(1./(1-diag(eps_Q)));
        diff=price_vector-new_price_vector;
        price_vector=new_price_vector;
    end

    p_inv=real((gamma_K'*(price_vector.^(1-eps_X))).^(1/(1-eps_X)));
    p_in=real((gamma_M'*(price_vector.^(1-eps_M))).^(1/(1-eps_M)));

    mu_vector=mu_vector_data.*(price_vector./p_in).^(1-diag(eps_Q));
    gamma_K=gamma_K_data.*(repmat(p_inv', industries, 1)./repmat(price_vector, 1, industries,1)).^(eps_X-1);
    gamma_M=gamma_M_data.*(repmat(p_in', industries, 1)./repmat(price_vector, 1, industries,1)).^(eps_M-1);
    gamma_M=gamma_M./repmat(sum(gamma_M), length(gamma_M),1);
    gamma_K=gamma_K./repmat(sum(gamma_K), length(gamma_K),1);
    diff_calibrate=max([0*max(abs(mu_vector-mu_vector_old)), max(max(abs(gamma_M-gamma_M_old))),max(max(abs(gamma_K-gamma_K_old)))]);
end
xi_vector=(xi_vector_data).*(price_vector.^(eps_D-1));
xi_vector=xi_vector./sum(xi_vector);

% once the price vector is known, we can solve for steady-state quantities.
for i_idx=1:industries
  sum_x=sum(gamma_K(:,i_idx).*price_vector.^(1-eps_X));
  sum_m=sum(gamma_M(:,i_idx).*price_vector.^(1-eps_M));
  for j_idx=1:industries
      tilde_gamma_M(j_idx,i_idx)=(price_vector(i_idx))^(eps_Q(i_idx,i_idx))*(mu_vector(i_idx)...
        *gamma_M(j_idx,i_idx)*sum_m^((eps_M-eps_Q(i_idx,i_idx))./(1-eps_M))*price_vector(j_idx)^(-eps_M));
      tilde_gamma_X(j_idx,i_idx)=(price_vector(i_idx))^(eps_Q(i_idx,i_idx))*...
        ((1-mu_vector(i_idx))*delta_K*alpha_vector(i_idx)*(1/var_beta-1+delta_K).^(-1+(1-eps_Q(i_idx,i_idx))*alpha_vector(i_idx))...
        *gamma_K(j_idx,i_idx)*sum_x^(-1+alpha_vector(i_idx)*(1-eps_Q(i_idx,i_idx))/(1-eps_X))*price_vector(j_idx)^(-eps_X));
  end
end

% q_vector is proportional (not exactly equal to) the steady-state quantity
% of the amount that each industry produces
% since the constant of proportionality, cbar in the notes, is multiplying all 
% quantity/consumption/labor supply variables, it will drop out of the
% "share" variables (which is what we are interested in computing, for the
% sake of the log-linearizations)

q_vector=(eye(industries)-tilde_gamma_M-tilde_gamma_X)\(xi_vector.*price_vector.^(-eps_D));
c_vector=xi_vector.*price_vector.^(-eps_D);
S_I_C=(xi_vector.^(1/eps_D).*(c_vector).^(1-1/eps_D))/sum((xi_vector.^(1/eps_D).*(c_vector).^(1-1/eps_D)));
S_I_C=(S_I_C*ones(1,industries))';

l_vector=q_vector.*(1-alpha_vector).*(1-mu_vector).*price_vector.^(diag(eps_Q)).*(1/var_beta-1+delta_K).^(alpha_vector.*(1-diag(eps_Q)))...
    .*(gamma_K'*(price_vector.^(1-eps_X))).^((alpha_vector.*(1-diag(eps_Q)))/(1-eps_X));
S_L_L=l_vector./sum(l_vector);
S_L_L=repmat(S_L_L,1,industries)';
S_M_Q=(q_vector*ones(1,industries))'.*((1./q_vector)*ones(1,industries)).* tilde_gamma_M;
S_X_Q=(q_vector*ones(1,industries))'.*((1./q_vector)*ones(1,industries)).* tilde_gamma_X;
S_C_Q=c_vector./q_vector;
S_M=mu_vector.*(gamma_M'*(price_vector.^(1-eps_M))).^((1-diag(eps_Q))/(1-eps_M)).*(price_vector).^(diag(eps_Q)-1);
S_1_M=repmat(price_vector.^(1-eps_M),1,industries)./(repmat((gamma_M'*(price_vector.^(1-eps_M))),1,industries)').*gamma_M;
S_1_X=repmat(price_vector.^(1-eps_X),1,industries)./(repmat((gamma_K'*(price_vector.^(1-eps_X))),1,industries)').*gamma_K;

S_1_M=(S_1_M./repmat(sum(S_1_M),industries,1))';
S_1_X=(S_1_X./repmat(sum(S_1_X),industries,1))';
S_X=(tilde_gamma_X*q_vector)'/sum((tilde_gamma_X*q_vector));
S_Y=(price_vector.*q_vector.*(1-mu_vector))'/sum((price_vector.*q_vector.*(1-mu_vector)));

for i_idx=1:industries
    t_S_M_Q(i_idx, (i_idx-1)*industries+(1:industries) ) = (S_M_Q(i_idx,:))';
    t_S_X_Q(i_idx, (i_idx-1)*industries+(1:industries) ) = (S_X_Q(i_idx,:))';
end
IminA=(I_N-diag(alpha_vector));
IminM=(I_N-diag(S_M));
P_1=IminA*inv(1/eps_LS*S_L_L+diag(alpha_vector));  %% this matrix is called Delta in the notes 
P_2=-eps_D*inv(S_1_X*(I_N+S_I_C*(eps_D-1)));  %% this matrix is called tilde_Delta in the notes. 

% matrices M_1 to M_5 are the same, independent of whether we allow for
% consumption-good durability.

S_M_eps = IminM \ (I_N + diag(S_M) * (eps_Q(1) -1)); 
M_1=var_beta*(1-delta_K)*S_1_X+beta_tilde*(P_1+I_N)*(I_N+(IminM\diag(S_M))*(I_N-S_1_M));  %%p_t+1
M_2=beta_tilde*(-IminA+P_1*diag(alpha_vector));  %k_t+1
M_3=beta_tilde*(I_N+P_1)*(I_N-inv(eps_Q)+(eps_Q*IminM)\(I_N+diag(S_M)*(eps_Q-I_N))) ;   %a_t
M_4=beta_tilde*(I_N+P_1)*IminA ;  %b_t
M_5=-S_1_X;  %p_t

M_6=zeros(industries); %p_t+1
M_7=1/delta_K*t_S_X_Q*T_1;  %k_t+1
M_8=(eps_M*t_S_M_Q*(T_1*S_1_M-T_2)+eps_Q*t_S_M_Q*T_1*(I_N-S_1_M)+eps_X*t_S_X_Q*(T_1*S_1_X-T_2))...
       -diag(S_C_Q)*eps_D*inv(I_N+S_I_C*(eps_D-1))-(I_N-t_S_M_Q*T_1)*... 
     (eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)));  %p_t
M_9= -((I_N-t_S_M_Q*T_1)*(I_N+P_1)*diag(alpha_vector)+(1/delta_K-1)*t_S_X_Q*T_1);  %k_t
M_10= (eps_Q-I_N)*t_S_M_Q*T_1-(I_N-t_S_M_Q*T_1)*(I_N+P_1*inv(eps_Q))*(IminM\(I_N+diag(S_M)*(eps_Q-I_N)))...
        -(I_N-t_S_M_Q*T_1)*P_1*(I_N-inv(eps_Q)) ;  %a_t;
M_11= -(I_N-t_S_M_Q*T_1)*(I_N+P_1)*IminA  ; %b_t;

temp_matrix1=[M_1 M_2 ; M_6 M_7];  %% this is the matrix that collectes next-period endog. variables
temp_matrix2=[M_5 zeros(industries); M_8 M_9]; %% this is the matrix that collectes current-period endog. variables
temp_matrix3=[M_3 M_4; M_10 M_11]; %% this is the matrix that collectes this-period exog. variables
matrix_A=-temp_matrix1\temp_matrix2;
matrix_B=-temp_matrix1\temp_matrix3;
[V, D] = eig(matrix_A);
EigsMatrixA=abs(diag(D));
[SortedD,EigsIdx]=sort(EigsMatrixA,1,'descend');
StableEigs=sum(EigsMatrixA<1);
UnstableEigs=sum(EigsMatrixA>=1);
invV=inv(V);
I_NA=eye(length(matrix_A));
SelectionMatrix_Pre=I_NA(EigsIdx,:);
SelectionMatrix_Post=I_NA(:,EigsIdx);
Vsorted=V*SelectionMatrix_Pre';
Dsorted=SelectionMatrix_Pre*D*SelectionMatrix_Post;
invVsorted=SelectionMatrix_Post'*invV;
if norm(Vsorted*Dsorted*invVsorted-matrix_A)>5e-07 || norm(diag(SelectionMatrix_Pre*diag(EigsMatrixA)*SelectionMatrix_Post)-SortedD)>5e-07
    error('sorting of eigenvalues does not work');
end;
unstableD=Dsorted(1:UnstableEigs,1:UnstableEigs);
stableD=Dsorted(UnstableEigs+1:end,UnstableEigs+1:end);
tildeMatrixB=invVsorted*matrix_B;
unstableB=tildeMatrixB(1:UnstableEigs,:);
stableB=tildeMatrixB(UnstableEigs+1:end,:);
DR_Jump_Exo   = -(invVsorted(1:UnstableEigs,1:UnstableEigs) \ (inv(unstableD)) * inv(eye(UnstableEigs)-inv(unstableD) )) * unstableB;
DR_Jump_State = -invVsorted(1:UnstableEigs,1:UnstableEigs) \ invVsorted(1:UnstableEigs,UnstableEigs+1:end) ;
if max(abs(imag([DR_Jump_State(:); DR_Jump_Exo(:)])))>5e-07
   error('imaginary policy rule');
else
    DR_Jump_Exo = real(DR_Jump_Exo);
    DR_Jump_State = real(DR_Jump_State);
end;

% The solution for the state variables is just the law of motion plus the influence of the policy rule
DR_State_State = matrix_A(UnstableEigs+1:end,UnstableEigs+1:end) + matrix_A(UnstableEigs+1:end,1:UnstableEigs) * DR_Jump_State ; 
DR_State_Exo = matrix_B(UnstableEigs+1:end,:) + matrix_A(UnstableEigs+1:end,1:UnstableEigs) * DR_Jump_Exo ;

filter_matrix_1_row_1 = (I_N+P_1)*diag(alpha_vector)+(eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))*DR_Jump_State;
filter_matrix_1_row_2 = S_Y*filter_matrix_1_row_1;

filter_matrix_2_row_1_a=(eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))*DR_Jump_Exo;  
filter_matrix_2_row_1_b=[P_1*(I_N-inv(eps_Q))+(P_1*inv(eps_Q)+I_N)*(IminM\((I_N+diag(S_M)*(eps_Q-I_N)))), (I_N+P_1)*IminA];  
filter_matrix_2_row_1_c=(I_N+P_1)*diag(alpha_vector)*DR_State_Exo;
filter_matrix_2_row_1=filter_matrix_2_row_1_a+filter_matrix_2_row_1_b+filter_matrix_2_row_1_c;
filter_matrix_2_row_2_A =S_Y*(filter_matrix_2_row_1(:,1:industries));

filter_matrix_1_A=filter_matrix_1_row_1;
filter_matrix_2_A=filter_matrix_2_row_1(:,1:industries);
final_filter_1_A=inv(filter_matrix_2_A);
final_filter_2_A=-((filter_matrix_2_A\filter_matrix_1_A)*DR_State_State)*inv(filter_matrix_1_A);
final_filter_3_A=-(filter_matrix_2_A\filter_matrix_1_A)*(DR_State_Exo(:,1:industries)-DR_State_State* ... 
    (((filter_matrix_1_A'*filter_matrix_1_A)\(filter_matrix_1_A'))*filter_matrix_2_A));

function_shock_A = @(shockm1, obst, obst1 ) filter_matrix_2_A\obst + final_filter_2_A * obst1 + final_filter_3_A * shockm1 ; 
filtered_shocks_A = zeros(length(data_sales_dt),industries);

for t_idx=2:size(data_sales_dt,1)
    filtered_shocks_A(t_idx,:)=function_shock_A(filtered_shocks_A(t_idx-1,:)',data_sales_dt(t_idx,:)',data_sales_dt(t_idx-1,:)');
end


matrix_eps_lag_A=-filter_matrix_2_A*final_filter_3_A;
matrix_data_lag_A=-filter_matrix_2_A*final_filter_2_A;
matrix_eps_A=filter_matrix_2_A;
productivity_shocks_kf_A=kfilter(data_sales_dt, matrix_data_lag_A, matrix_eps_A, matrix_eps_lag_A);
if max(abs(imag(filtered_shocks_A)))>5e-6
   error('imaginary filtered shocks');
end

filtered_shocks_A_kf=productivity_shocks_kf_A((burn_in+1):end,:);

if abs(eps_M-.1)<.01
    csvwrite('filtered_shocks_eps_01.csv', filtered_shocks_A_kf)
end
if abs(eps_M-1)<.01
    csvwrite('filtered_shocks_eps_10.csv', filtered_shocks_A_kf)
end

optionsFactoran = optimset('Display','iter','TolFun',1e-8, 'TolX', 1e-8, 'MaxIter',2000');
correlation=zeros(industries,industries);   
coskewness=zeros(industries,industries,industries);
cokurtosis=zeros(industries,industries,industries,industries);
 
covariance_=zeros(industries,industries);
coskewness_=zeros(industries,industries^2);
cokurtosis_=zeros(industries,industries^3);
 
 filtered_shocks_A_kf_dm=filtered_shocks_A_kf-ones(length(filtered_shocks_A_kf),1)*mean(filtered_shocks_A_kf);
 
% These are the correlation/coskewness/cokurtosis tensors which will eventually be plotted in the left panel of Figure 2.

 for ii=1:industries
     for jj=1:industries
         correlation(ii,jj)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj))./std(filtered_shocks_A_kf_dm(:,ii))./std(filtered_shocks_A_kf_dm(:,jj));         
         covariance_(ii,jj)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj));         
         for kk=1:industries
             coskewness(ii,jj,kk)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj).*filtered_shocks_A_kf_dm(:,kk))./std(filtered_shocks_A_kf_dm(:,ii))./std(filtered_shocks_A_kf_dm(:,jj))./std(filtered_shocks_A_kf_dm(:,kk)); 
             coskewness_(ii,(jj-1)*industries+kk)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj).*filtered_shocks_A_kf_dm(:,kk));
            for ll=1:industries
                cokurtosis(ii,jj,kk,ll)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj).*filtered_shocks_A_kf_dm(:,kk).*filtered_shocks_A_kf_dm(:,ll))./std(filtered_shocks_A_kf_dm(:,ii))./std(filtered_shocks_A_kf_dm(:,jj))./std(filtered_shocks_A_kf_dm(:,kk))./std(filtered_shocks_A_kf_dm(:,ll));
                cokurtosis_(ii,(jj-1)*industries^2+(kk-1)*industries+ll)=mean(filtered_shocks_A_kf_dm(:,ii).*filtered_shocks_A_kf_dm(:,jj).*filtered_shocks_A_kf_dm(:,kk).*filtered_shocks_A_kf_dm(:,ll));
            end
         end
     end
 end
 
% Perform PCA and MCA to the unnormalized (not dividing by the standard deviation) covariance/coskewness/cokurtosis tensors
% Extract the single common component, and the portion of the tensor which is solely industry-specific.

 [u_cov s_cov v_cov]=svd(covariance_ );
 common_cov=u_cov(:,1)*v_cov(:,1)'*s_cov(1,1);
 ind_cov=diag(max(1e-8, diag(covariance_)-diag(common_cov)));
 
 [u_skew s_skew v_skew]=svd(coskewness_, 'econ');
 common_skew=u_skew(:,1)*v_skew(:,1)'*s_skew(1,1);
 ind_skew=zeros(industries,industries^2);
 for ii=1:industries
     ind_skew(ii,ii+industries*(ii-1))=coskewness_(ii,ii+industries*(ii-1))- common_skew(ii,ii+industries*(ii-1));
 end
 
 [u_kurt s_kurt v_kurt]=svd(cokurtosis_, 'econ');
 common_kurt=u_kurt(:,1)*v_kurt(:,1)'*s_kurt(1,1);
 ind_kurt=zeros(industries,industries^3);
 for ii=1:industries
     ind_kurt(ii,ii+industries*(ii-1)+industries^2*(ii-1))=cokurtosis_(ii,ii+industries*(ii-1)+industries^2*(ii-1))- common_kurt(ii,ii+industries*(ii-1)+industries^2*(ii-1));
 end

  for ii=1:industries
      for jj=1:industries
          if ii ~=jj
                ind_kurt(ii,jj+industries*(jj-1)+industries^2*(ii-1))=cokurtosis_(ii,jj+industries*(jj-1)+industries^2*(ii-1))- common_kurt(ii,jj+industries*(jj-1)+industries^2*(ii-1));
                ind_kurt(ii,jj+industries*(ii-1)+industries^2*(jj-1))=cokurtosis_(ii,jj+industries*(ii-1)+industries^2*(jj-1))- common_kurt(ii,jj+industries*(ii-1)+industries^2*(jj-1));
                ind_kurt(ii,ii+industries*(jj-1)+industries^2*(jj-1))=cokurtosis_(ii,ii+industries*(jj-1)+industries^2*(jj-1))- common_kurt(ii,ii+industries*(jj-1)+industries^2*(jj-1));
          end
      end
 end
     
 var_model=zeros(industries,industries);
 var_common=zeros(industries,industries);
 var_ind=zeros(industries,industries);
 
 coskewness_model=zeros(industries,industries,industries);
 coskewness_common=zeros(industries,industries,industries);
 coskewness_ind=zeros(industries,industries,industries);
 
 cokurtosis_model=zeros(industries,industries,industries, industries);
 cokurtosis_common=zeros(industries,industries,industries, industries);
 cokurtosis_ind=zeros(industries,industries,industries, industries);
  
 var_common_output=0;
 var_ind_output=0;

 skewness_common_output=0;
 skewness_ind_output=0;
 
 kurtosis_common_output=0;
 kurtosis_ind_output=0; 
 
 matrix_to_power=zeros(industries,26);
 
 for tt=0:25
      matrix_to_power(:,tt+1)=filter_matrix_1_row_2*mpower(DR_State_State,tt)*DR_State_Exo(:,1:industries);
 end
 
% These are the calculations which produce the in the right panel of Figure 3.
 for ii=1:industries
     for jj=1:industries    
         var_ind_output=var_ind_output+ind_cov(ii,jj)*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj);
         var_common_output=var_common_output+common_cov(ii,jj)*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj);
       for tt=0:25
             var_ind_output=var_ind_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*ind_cov(ii,jj);
             var_common_output=var_common_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*common_cov(ii,jj);
       end
         for kk=1:industries             
            skewness_ind_output=skewness_ind_output+ind_skew(ii,kk+industries*(jj-1))*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj)*filter_matrix_2_row_2_A(kk);
            skewness_common_output=skewness_common_output+common_skew(ii,kk+industries*(jj-1))*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj)*filter_matrix_2_row_2_A(kk);

            for tt=0:25       
                   skewness_ind_output= skewness_ind_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*matrix_to_power(kk,tt+1)*ind_skew(ii,kk+industries*(jj-1));
                   skewness_common_output= skewness_common_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*matrix_to_power(kk,tt+1)*common_skew(ii,kk+industries*(jj-1));
            end
            
            for ll=1:industries                
               kurtosis_ind_output=kurtosis_ind_output+ind_kurt(ii,(kk-1)*industries+industries^2*(jj-1)+ll)*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj)*filter_matrix_2_row_2_A(kk)*filter_matrix_2_row_2_A(ll);
                kurtosis_common_output=kurtosis_common_output+common_kurt(ii,(kk-1)*industries+industries^2*(jj-1)+ll)*filter_matrix_2_row_2_A(ii)*filter_matrix_2_row_2_A(jj)*filter_matrix_2_row_2_A(kk)*filter_matrix_2_row_2_A(ll);
                
                for tt=0:25
                   kurtosis_ind_output= kurtosis_ind_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*matrix_to_power(kk,tt+1)*matrix_to_power(ll,tt+1)*ind_kurt(ii,(kk-1)*industries+industries^2*(jj-1)+ll);
                   kurtosis_common_output= kurtosis_common_output+matrix_to_power(ii,tt+1)*matrix_to_power(jj,tt+1)*matrix_to_power(kk,tt+1)*matrix_to_power(ll,tt+1)*common_kurt(ii,(kk-1)*industries+industries^2*(jj-1)+ll);
                end
            end
         end
     end
 end

% Also, for comparison sake, compute the R^2(common factor) using the mle estimate of the common factor / industry-specific shocks. 
[lambda_A_kf, psi_A_kf, T_A_kf, stats_A_kf, F_A_kf]=factoran_(real(filtered_shocks_A_kf),  1 , ...
        'Nobs' , size(filtered_shocks_A_kf,1)-1, 'optimopts',optionsFactoran); 
 sigma_Matrix_A_kf=	lambda_A_kf*lambda_A_kf'+diag(psi_A_kf);
 cov_model_output_A_kf=filter_matrix_2_row_2_A*sigma_Matrix_A_kf*filter_matrix_2_row_2_A';
 cov_ind_output_A_kf=filter_matrix_2_row_2_A*diag(psi_A_kf)*filter_matrix_2_row_2_A'; 
 for t_idx=0:25 
     cov_model_output_A_kf=cov_model_output_A_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*sigma_Matrix_A_kf*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     cov_ind_output_A_kf=cov_ind_output_A_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*diag(psi_A_kf)*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
  end
 
 results_table(counter,:)=[eps_M mean(mean(correlation)) mean(mean(mean(coskewness))) mean(mean(mean(mean(cokurtosis))))  var_ind_output/(var_ind_output+var_common_output) ...
    skewness_ind_output/(skewness_common_output+skewness_ind_output) kurtosis_ind_output/(kurtosis_common_output+kurtosis_ind_output) ... 
    var_ind_output var_common_output skewness_ind_output  skewness_common_output kurtosis_ind_output kurtosis_common_output]
 