In this document, I describe the pieces of code that will produce the main tables and figures of "Sources of Variation in Social Networks."  Even though all of the figures were produced using STATA, some of the calculations behind the figures were performed with MATLAB or Mathematica.  You will need all three pieces of software to reproduce the figures and tables.  If you have any questions, please do not hesitate to contact me at atalay@uchicago.edu.   

As I mention in the text, the data may be downloaded at http://snap.stanford.edu/data/index.html.  With the data, the code assumes you have a csv file with the edges (called edges.csv), a csv file with the abstracts (which is only really necessary to produce Figure 11.)

-- exact.do produces Figures 1.

-- fig23.do produces Figures 2, 3, and 6. 
 
-- analysis.do produces Figures 4, 5, 7, 8, and 10.

-- fig9.do produces Figure 9.

-- journalsA.do and journalsB.do, in combination, produce Figure 11.

-- jrbounds.do produces the figures in Appendix C.

-- nparm.do produces the figures in Appendix E 

-- proof2.do produces the figure in Appendix F 

-- theory.nb is the Mathematica notebook which contains the calculations necessary to produce Figures 2 and 3.

-- journal.nb is the Mathematica notebook which takes formle2.csv and then produces journalReults.csv

-- analysis.nb is the Mathematica notebook which contains the calculations necessary to produce some of the figures in analysis.do.

Matlab Files

-- mlemax.m:  This is the master file for the maximum likelihood estimation.  

-- mlefunG.m: This computes the MLE of the first column.

-- mlefunR.m: This computes the MLE of the second column.

-- mlefunpb.m: This computes the MLE of the extended model

-- mlefunnp.m: This computes the MLE of the extended model, "nonparametrically" (as in Appendix E)

-- annealSm.m: This computes the MLE of the third column.  This file, calls pbarfun.m (which computes pbar every few iterations) and mlefunpb.m (which computes the log likelihood). 

-- anneal.m : This computes the MLE of the third colmn (corresponding to the "nonparametric" case).  This file, calls pbarfunnp.m (which computes pbar every few iterations) and mlefunnp.m (which computes the log likelihood). 

Note : This piece of code is a lighly modified version of the code written by Joachim Vandekerckhove.  See http://www.mathworks.co.uk/matlabcentral/fileexchange/10548

I used a simulated annealing algorithm (instead of matlab's built in fminsearch command) because of concerns about hitting local (rather than global) maxima of the log likelihood function. 

-- test.m : This computes the test statistics, as plotted in Figure 6 of the paper (see fig23.do)

-- mlevar.m:  Computes the standard errors (after the maximization has been completed)

E.A., February 6, 2013