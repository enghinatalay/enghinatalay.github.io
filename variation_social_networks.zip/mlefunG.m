%% This Piece of code computes the log-likelood of the base JR model.  It is used in combination 
%% with fminsearch to find the MLE of the base JR model.

function f=mlefun(par, A)

m=par(1);
r=par(2);

combos=unique(A, 'rows');  %Compress the data so that any age-degree combination is listed only once.  
combos=[combos zeros(length(combos),1)];
for it=1:length(combos)
  combos(it,3)=sum(A(:,1)==combos(it,1) & A(:,2)==combos(it,2));
end

prob=zeros(length(combos),1);
for it=1:length(combos)
  qq=combos(it,1); 
  aa=combos(it,2);
  prob(it)=log(1+r)+gammaln((m+1)*r+1)-gammaln(m*r)+gammaln(m*r+qq)-gammaln((m+1)*r+2+qq);
end

[m r  sum(prob.*combos(:,3))/1e3]
f=-sum(prob.*combos(:,3));




