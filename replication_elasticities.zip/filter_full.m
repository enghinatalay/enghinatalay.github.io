% This file is called by filter_master.m and computes the correlation of
% productivity shocks, the fraction of aggregate variation that is caused
% by common shocks, and historical decompositions. It calls kfilter.m and
% factoran_.m .  It uses the data that are produced by io_read.do and
% io_read_foreign.do 

delta_K=0.10;
var_beta=0.96;
counter=counter+1;
eps_D=parameters(1);
eps_Q=parameters(2);
eps_M=parameters(3);
eps_X=parameters(4);
durable_consumption=parameters(6);
data_set=parameters(7);
eps_LS=parameters(5);
burn_in=parameters(8);

if data_set==1
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt.csv',1,0);
elseif data_set==2
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_hp.csv',1,0);     
elseif data_set==3
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ_72.csv');
  data_O=csvread('dataOJ_72.csv');
  data_time=csvread('ioJ_data_dt.csv',1,0);     
elseif data_set==4
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dtB.csv',1,0);     
elseif data_set==5
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt_perl_2.csv',1,0);  
  var_beta=var_beta^2;
  delta_K=1-(1-delta_K)^2;
elseif data_set==6
  gamma_K=csvread('dataKJ_coarse.csv');
  gamma_M=csvread('dataMJ_coarse.csv');
  data_O=csvread('dataOJ_coarse.csv');
  data_time=csvread('ioJ_data_dt_coarse.csv',1,0);   
elseif data_set==7
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt_early.csv',1,0);     
elseif data_set==8
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt_late.csv',1,0);     
elseif data_set==9
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt_outliers.csv',1,0);     
elseif data_set==10
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data.csv',1,0);
elseif data_set==11
  gamma_K=csvread('dataKJ.csv');
  gamma_M=csvread('dataMJ.csv');
  data_O=csvread('dataOJ.csv');
  data_time=csvread('ioJ_data_dt.csv',1,0);
  data_time=data_time(1:46,:);
elseif data_set==12
  gamma_K=csvread('dataKJ_JPN.csv');
  gamma_M=csvread('dataMJ_JPN.csv');
  data_O=csvread('dataOJ_JPN.csv',1,0);
  data_time=csvread('ioJ_data_dt_JPN.csv',1,0);       
elseif data_set==13
  gamma_K=csvread('dataKJ_ITA.csv');
  gamma_M=csvread('dataMJ_ITA.csv');
  data_O=csvread('dataOJ_ITA.csv',1,0);
  data_time=csvread('ioJ_data_dt_ITA.csv',1,0);    
elseif data_set==14
  gamma_K=csvread('dataKJ_DNK.csv');
  gamma_M=csvread('dataMJ_DNK.csv');
  data_O=csvread('dataOJ_DNK.csv',1,0);
  data_time=csvread('ioJ_data_dt_DNK.csv',1,0); 
elseif data_set==15
  gamma_K=csvread('dataKJ_FRA.csv');
  gamma_M=csvread('dataMJ_FRA.csv');
  data_O=csvread('dataOJ_FRA.csv',1,0);
  data_time=csvread('ioJ_data_dt_FRA.csv',1,0);  
elseif data_set==16
  gamma_K=csvread('dataKJ_ESP.csv');
  gamma_M=csvread('dataMJ_ESP.csv');
  data_O=csvread('dataOJ_ESP.csv',1,0);
  data_time=csvread('ioJ_data_dt_ESP.csv',1,0);       
elseif data_set==17
  gamma_K=csvread('dataKJ_NLD.csv');
  gamma_M=csvread('dataMJ_NLD.csv');
  data_O=csvread('dataOJ_NLD.csv',1,0);
  data_time=csvread('ioJ_data_dt_NLD.csv',1,0);   
elseif data_set==18
  gamma_K=csvread('dataKJ_USA.csv');
  gamma_M=csvread('dataMJ_USA.csv');
  data_O=csvread('dataOJ_USA.csv',1,0);
  data_time=csvread('ioJ_data_dt_USA.csv',1,0);   
end
 
% the McGrattan and Schmitz correction. No need to do this for foreign
% countries since a line similar to this is already included in
% io_read_foreign.do 
if data_set<=12  
   gamma_K=gamma_K*0.65+eye(length(gamma_K))*0.35;
end

gamma_M=gamma_M./repmat(sum(gamma_M), length(gamma_M),1);
gamma_K=gamma_K./repmat(sum(gamma_K), length(gamma_K),1);
mu_vector=data_O(:,3); 

gamma_M_data=gamma_M;
gamma_K_data=gamma_K;
mu_vector_data=mu_vector;

if durable_consumption==1
    delta_C=max(0.4, data_O(:,6));
elseif durable_consumption==2
   delta_C=max(0.3, data_O(:,6));
   delta_C(20)=.30;  % The depreciation rate for autos is 0.35; set this at
                     % 0.3 so that all durables have the same depreciation
                     % rate.
else
    delta_C=max(1, data_O(:,6));
end

industries=length(gamma_M);
% set the minimum values of the preference vector to be some positive but 
% small value, to improve the numerical performance of the filter.
xi_vector=max(6e-3,data_O(:,4));
xi_vector_data=xi_vector/sum(xi_vector);

data_sales_dt=data_time(:,1:industries);
alpha_vector=data_O(:,1)./(data_O(:,1)+data_O(:,2));
I_N=eye(industries);
eps_Q=eps_Q*I_N;
beta_tilde= 1-var_beta*(1-delta_K);
tilde_gamma_M=zeros(industries);
tilde_gamma_X=zeros(industries);
t_S_M_Q=zeros(industries,industries^2);
t_S_X_Q=zeros(industries,industries^2);
T_1 = kron(ones(industries,1), speye(industries));
T_2 = kron(speye(industries), ones(industries,1));

% this portion of code computes the steady state allocation.
% It follows a fixed point algorithm, terminating at the point at which 
% the price vector clears each industry's market clearing condition.

diff_calibrate=1;
while diff_calibrate>1e-3
    price_vector=ones(industries,1);
    gamma_K_old=gamma_K;
    gamma_M_old=gamma_M;
    mu_vector_old=mu_vector;
    diff=price_vector;
    while max(abs(diff))>1e-7
        new_price_vector=((1-mu_vector).*(1/var_beta-(1-delta_K)).^(alpha_vector.*(1-diag(eps_Q)))...
            .*(gamma_K'*(price_vector.^(1-eps_X))).^(alpha_vector.*(1-diag(eps_Q))/(1-eps_X)) ...
             + mu_vector.*(gamma_M'*(price_vector.^(1-eps_M))).^((1-diag(eps_Q))/(1-eps_M))).^(1./(1-diag(eps_Q)));
        diff=price_vector-new_price_vector;
        price_vector=new_price_vector;
    end

    p_inv=real((gamma_K'*(price_vector.^(1-eps_X))).^(1/(1-eps_X)));
    p_in=real((gamma_M'*(price_vector.^(1-eps_M))).^(1/(1-eps_M)));
    mu_vector=mu_vector_data.*(price_vector./p_in).^(1-diag(eps_Q));
    gamma_K=gamma_K_data.*(repmat(p_inv', industries, 1)./repmat(price_vector, 1, industries,1)).^(eps_X-1);
    gamma_M=gamma_M_data.*(repmat(p_in', industries, 1)./repmat(price_vector, 1, industries,1)).^(eps_M-1);
    gamma_M=gamma_M./repmat(sum(gamma_M), length(gamma_M),1);
    gamma_K=gamma_K./repmat(sum(gamma_K), length(gamma_K),1);
    diff_calibrate=max([0*max(abs(mu_vector-mu_vector_old)), max(max(abs(gamma_M-gamma_M_old))),max(max(abs(gamma_K-gamma_K_old)))]);
end
xi_vector=(xi_vector_data).*(price_vector.^(eps_D-1)).*((1-var_beta*(1-delta_C))./(var_beta.*delta_C)).^(eps_D-1);
xi_vector=xi_vector./sum(xi_vector);

% once the price vector is known, we can solve for steady-state quantities.
for i_idx=1:industries
  sum_x=sum(gamma_K(:,i_idx).*price_vector.^(1-eps_X));
  sum_m=sum(gamma_M(:,i_idx).*price_vector.^(1-eps_M));
  for j_idx=1:industries
      tilde_gamma_M(j_idx,i_idx)=(price_vector(i_idx))^(eps_Q(i_idx,i_idx))*(mu_vector(i_idx)...
        *gamma_M(j_idx,i_idx)*sum_m^((eps_M-eps_Q(i_idx,i_idx))./(1-eps_M))*price_vector(j_idx)^(-eps_M));
      tilde_gamma_X(j_idx,i_idx)=(price_vector(i_idx))^(eps_Q(i_idx,i_idx))*...
        ((1-mu_vector(i_idx))*delta_K*alpha_vector(i_idx)*(1/var_beta-1+delta_K).^(-1+(1-eps_Q(i_idx,i_idx))*alpha_vector(i_idx))...
        *gamma_K(j_idx,i_idx)*sum_x^(-1+alpha_vector(i_idx)*(1-eps_Q(i_idx,i_idx))/(1-eps_X))*price_vector(j_idx)^(-eps_X));
  end
end

% q_vector is proportional (not exactly equal to) the steady-state quantity
% of the amount that each industry produces
% since the constant of proportionality, cbar in the notes, is multiplying all 
% quantity/consumption/labor supply variables, it will drop out of the
% "share" variables (which is what we are interested in computing, for the
% sake of the log-linearizations)

q_vector=(eye(industries)-tilde_gamma_M-tilde_gamma_X)\(xi_vector.*delta_C.^(eps_D)...
   .*(1-var_beta*(1-delta_C)).^(-eps_D).*price_vector.^(-eps_D));
c_vector=1./delta_C.*xi_vector.*(delta_C./(1-var_beta*(1-delta_C))).^eps_D.*price_vector.^(-eps_D);
S_I_C=(xi_vector.^(1/eps_D).*(delta_C.*c_vector).^(1-1/eps_D))/sum((xi_vector.^(1/eps_D).*(delta_C.*c_vector).^(1-1/eps_D)));
S_I_C=(S_I_C*ones(1,industries))';

l_vector=q_vector.*(1-alpha_vector).*(1-mu_vector).*price_vector.^(diag(eps_Q)).*(1/var_beta-1+delta_K).^(alpha_vector.*(1-diag(eps_Q)))...
    .*(gamma_K'*(price_vector.^(1-eps_X))).^((alpha_vector.*(1-diag(eps_Q)))/(1-eps_X));
S_L_L=l_vector./sum(l_vector);
S_L_L=repmat(S_L_L,1,industries)';
S_M_Q=(q_vector*ones(1,industries))'.*((1./q_vector)*ones(1,industries)).* tilde_gamma_M;
S_X_Q=(q_vector*ones(1,industries))'.*((1./q_vector)*ones(1,industries)).* tilde_gamma_X;
S_C_Q=delta_C.*c_vector./q_vector;
S_M=mu_vector.*(gamma_M'*(price_vector.^(1-eps_M))).^((1-diag(eps_Q))/(1-eps_M)).*(price_vector).^(diag(eps_Q)-1);
S_1_M=repmat(price_vector.^(1-eps_M),1,industries)./(repmat((gamma_M'*(price_vector.^(1-eps_M))),1,industries)').*gamma_M;
S_1_X=repmat(price_vector.^(1-eps_X),1,industries)./(repmat((gamma_K'*(price_vector.^(1-eps_X))),1,industries)').*gamma_K;
S_1_M=(S_1_M./repmat(sum(S_1_M),industries,1))';
S_1_X=(S_1_X./repmat(sum(S_1_X),industries,1))';
S_X=(tilde_gamma_X*q_vector)'/sum((tilde_gamma_X*q_vector));
S_Y=(price_vector.*q_vector.*(1-mu_vector))'/sum((price_vector.*q_vector.*(1-mu_vector)));

for i_idx=1:industries
    t_S_M_Q(i_idx, (i_idx-1)*industries+(1:industries) ) = (S_M_Q(i_idx,:))';
    t_S_X_Q(i_idx, (i_idx-1)*industries+(1:industries) ) = (S_X_Q(i_idx,:))';
end
IminA=(I_N-diag(alpha_vector));
IminM=(I_N-diag(S_M));
P_1=IminA*inv(1/eps_LS*S_L_L+diag(alpha_vector));  %% this matrix is called vartheta in the notes 
P_2=-eps_D*inv(S_1_X*(I_N-var_beta*(I_N-diag(delta_C)))*(I_N+S_I_C*(eps_D-1)));  %% this matrix is called tilde_vartheta in the notes. 

% matrices M_1 to M_5 are the same, independent of whether we allow for
% consumption-good durability.
% these are ither equations 53-54 (in the durables case), or the
% equations that are on the bottom of page 61 (in the no durables case).
S_M_eps = IminM \ (I_N + diag(S_M) * (eps_Q(1) -1)); 
M_1=var_beta*(1-delta_K)*S_1_X+beta_tilde*(P_1+I_N)*(I_N+(IminM\diag(S_M))*(I_N-S_1_M));  %%p_t+1
M_2=beta_tilde*(-IminA+P_1*diag(alpha_vector));  %k_t+1
M_3=beta_tilde*(I_N+P_1)*(I_N-inv(eps_Q)+(eps_Q*IminM)\(I_N+diag(S_M)*(eps_Q-I_N))) ;   %a_t
M_4=beta_tilde*(I_N+P_1)*IminA ;  %b_t
M_5=-S_1_X;  %p_t

if durable_consumption==0
    M_6=zeros(industries); %p_t+1
    M_7=1/delta_K*t_S_X_Q*T_1;  %k_t+1
    M_8=(eps_M*t_S_M_Q*(T_1*S_1_M-T_2)+eps_Q*t_S_M_Q*T_1*(I_N-S_1_M)+eps_X*t_S_X_Q*(T_1*S_1_X-T_2))...
       -diag(S_C_Q)*eps_D*inv(I_N+S_I_C*(eps_D-1))-(I_N-t_S_M_Q*T_1)*... 
     (eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)));  %p_t
    M_9= -((I_N-t_S_M_Q*T_1)*(I_N+P_1)*diag(alpha_vector)+(1/delta_K-1)*t_S_X_Q*T_1);  %k_t
    M_10= (eps_Q-I_N)*t_S_M_Q*T_1-(I_N-t_S_M_Q*T_1)*(I_N+P_1*inv(eps_Q))*(IminM\(I_N+diag(S_M)*(eps_Q-I_N)))...
        -(I_N-t_S_M_Q*T_1)*P_1*(I_N-inv(eps_Q)) ;  %a_t;
    M_11= -(I_N-t_S_M_Q*T_1)*(I_N+P_1)*IminA  ; %b_t;
    M_12 = diag(S_C_Q)  ; % d_t
else
    M_6=(diag(delta_C)\diag(S_C_Q))*P_2*(S_1_X*var_beta*diag(delta_C-delta_K)+...
        beta_tilde*(I_N+P_1)*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))     ; %p_t+1
    M_7=1/delta_K*t_S_X_Q*T_1+inv(diag(delta_C))*diag(S_C_Q)*beta_tilde*P_2*(-IminA+P_1*diag(alpha_vector));  %k_t+1
    M_8=(eps_M*t_S_M_Q*(T_1*S_1_M-T_2)+eps_Q*t_S_M_Q*T_1*(I_N-S_1_M)+eps_X*t_S_X_Q*(T_1*S_1_X-T_2))...
      -(I_N-t_S_M_Q*T_1)*(eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))+...
     (I_N-inv(diag(delta_C)))*diag(S_C_Q)*P_2*(beta_tilde*(I_N+P_1)*(I_N+(IminM\diag(S_M))*(I_N-S_1_M))+ ...
     S_1_X*var_beta*diag(delta_C-delta_K));  %p_t
    M_9= -((I_N-t_S_M_Q*T_1)*(I_N+P_1)*diag(alpha_vector)+(1/delta_K-1)*t_S_X_Q*T_1) + ...
        (I_N-inv(diag(delta_C)))*diag(S_C_Q)*beta_tilde*P_2*(-IminA+P_1*diag(alpha_vector));  %k_t
    M_10=(eps_Q-I_N)*t_S_M_Q*T_1-(I_N-t_S_M_Q*T_1)*(I_N+P_1*inv(eps_Q))*(IminM\(I_N+diag(S_M)*(eps_Q-I_N)))...
        -(I_N-t_S_M_Q*T_1)*P_1*(I_N-inv(eps_Q)) + diag(S_C_Q)*P_2*beta_tilde*(I_N+P_1)* ...
        ((eps_Q*IminM)\(I_N+diag(S_M)*(eps_Q-I_N))+I_N-inv(eps_Q));  %a_t;
    M_11= diag(S_C_Q)*P_2*beta_tilde*(I_N+P_1)*IminA -(I_N-t_S_M_Q*T_1)*(I_N+P_1)*IminA  ; %b_t;   
    M_12= diag(S_C_Q) ; %d_t
end

temp_matrix1=[M_1 M_2 ; M_6 M_7 ];  %% this is the matrix that collectes next-period endog. variables
temp_matrix2=[M_5 zeros(industries); M_8 M_9]; %% this is the matrix that collectes current-period endog. variables
temp_matrix3=[M_3 M_4 zeros(industries); M_10 M_11 M_12]; %% this is the matrix that collectes this-period exog. variables
matrix_A=-temp_matrix1\temp_matrix2;
matrix_B=-temp_matrix1\temp_matrix3;
[V, D] = eig(matrix_A);
EigsMatrixA=abs(diag(D));
[SortedD,EigsIdx]=sort(EigsMatrixA,1,'descend');
StableEigs=sum(EigsMatrixA<1);
UnstableEigs=sum(EigsMatrixA>=1);
invV=inv(V);
I_NA=eye(length(matrix_A));
SelectionMatrix_Pre=I_NA(EigsIdx,:);
SelectionMatrix_Post=I_NA(:,EigsIdx);
Vsorted=V*SelectionMatrix_Pre';
Dsorted=SelectionMatrix_Pre*D*SelectionMatrix_Post;
invVsorted=SelectionMatrix_Post'*invV;
if norm(Vsorted*Dsorted*invVsorted-matrix_A)>5e-07 || norm(diag(SelectionMatrix_Pre*diag(EigsMatrixA)*SelectionMatrix_Post)-SortedD)>5e-07
    error('sorting of eigenvalues does not work');
end;
unstableD=Dsorted(1:UnstableEigs,1:UnstableEigs);
stableD=Dsorted(UnstableEigs+1:end,UnstableEigs+1:end);
tildeMatrixB=invVsorted*matrix_B;
unstableB=tildeMatrixB(1:UnstableEigs,:);
stableB=tildeMatrixB(UnstableEigs+1:end,:);
% these are from equation 58 of the paper
DR_Jump_Exo   = -(invVsorted(1:UnstableEigs,1:UnstableEigs) \ (inv(unstableD)) * inv(eye(UnstableEigs)-inv(unstableD) )) * unstableB;
DR_Jump_State = -invVsorted(1:UnstableEigs,1:UnstableEigs) \ invVsorted(1:UnstableEigs,UnstableEigs+1:end) ;
if max(abs(imag([DR_Jump_State(:); DR_Jump_Exo(:)])))>5e-07
   error('imaginary policy rule');
else
    DR_Jump_Exo = real(DR_Jump_Exo);
    DR_Jump_State = real(DR_Jump_State);
end;

% The solution for the state variables is just the law of motion plus the influence of the policy rule
DR_State_State = matrix_A(UnstableEigs+1:end,UnstableEigs+1:end) + matrix_A(UnstableEigs+1:end,1:UnstableEigs) * DR_Jump_State ; 
DR_State_Exo = matrix_B(UnstableEigs+1:end,:) + matrix_A(UnstableEigs+1:end,1:UnstableEigs) * DR_Jump_Exo ;

% filter_matrix_1_row_1 and filter_matrix_2_row_1 are given in Equation 60
% in Appendix F4 (see footnote 40)

filter_matrix_1_row_1 = (I_N+P_1)*diag(alpha_vector)+(eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))*DR_Jump_State;
filter_matrix_1_row_2 = S_Y*(filter_matrix_1_row_1-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_State);

filter_matrix_2_row_1_a=(eps_Q*(IminM\diag(S_M))*(I_N-S_1_M)+P_1*(I_N+(IminM\diag(S_M))*(I_N-S_1_M)))*DR_Jump_Exo;  
filter_matrix_2_row_1_b=[P_1*(I_N-inv(eps_Q))+(P_1*inv(eps_Q)+I_N)*(IminM\((I_N+diag(S_M)*(eps_Q-I_N)))), (I_N+P_1)*IminA, zeros(industries)];  
filter_matrix_2_row_1=filter_matrix_2_row_1_a+filter_matrix_2_row_1_b;

filter_matrix_2_row_2_A =S_Y*[(filter_matrix_2_row_1(:,1:industries))-diag(S_M)*(eps_Q-I_N)-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_Exo(:,1:industries)];
filter_matrix_2_row_2_B =S_Y*[(filter_matrix_2_row_1(:,(1+industries):(2*industries)))-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_Exo(:,(1+industries):(2*industries))];
% for these equations, see appendix F8 of the paper.
tt=(filter_matrix_2_row_1(:,1:industries))-diag(S_M)*(eps_Q-I_N)-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_Exo(:,1:industries);
filter_matrix_2_row_2_D =S_Y*[tt(:,1:industries-1), filter_matrix_2_row_1(:,3*industries)];

filter_matrix_1_A=filter_matrix_1_row_1;
filter_matrix_2_A=filter_matrix_2_row_1(:,1:industries);
final_filter_1_A=inv(filter_matrix_2_A);
final_filter_2_A=-((filter_matrix_2_A\filter_matrix_1_A)*DR_State_State)*inv(filter_matrix_1_A);
final_filter_3_A=-(filter_matrix_2_A\filter_matrix_1_A)*(DR_State_Exo(:,1:industries)-DR_State_State* ... 
    (((filter_matrix_1_A'*filter_matrix_1_A)\(filter_matrix_1_A'))*filter_matrix_2_A));

filter_matrix_1_B=filter_matrix_1_row_1;
filter_matrix_2_B=filter_matrix_2_row_1(:,1+industries:(2*industries));
final_filter_1_B=inv(filter_matrix_2_B);
final_filter_2_B=-((filter_matrix_2_B\filter_matrix_1_B)*DR_State_State)*inv(filter_matrix_1_B);
final_filter_3_B=-(filter_matrix_2_B\filter_matrix_1_B)*((DR_State_Exo(:,1+industries:(2*industries)))-DR_State_State* ... 
    (((filter_matrix_1_B'*filter_matrix_1_B)\(filter_matrix_1_B'))*filter_matrix_2_B));

filter_matrix_1_D=filter_matrix_1_row_1;
filter_matrix_2_D=filter_matrix_2_row_1(:,[1:industries-1 3*industries]);
final_filter_1_D=inv(filter_matrix_2_D);
final_filter_2_D=-((filter_matrix_2_D\filter_matrix_1_D)*DR_State_State)*inv(filter_matrix_1_D);
final_filter_3_D=-(filter_matrix_2_D\filter_matrix_1_D)*((DR_State_Exo(:,[1:industries-1 3*industries]))-DR_State_State* ... 
    (((filter_matrix_1_D'*filter_matrix_1_D)\(filter_matrix_1_D'))*filter_matrix_2_D));

% this is the filter that is defined by Equations (11) of the paper for
% the case of tfp shocks. The filters for labor-augmenting shocks
% (see Table 4; column 2), or for tfp shocks (in the non-government industry
% plus government spending shocks (see the final column of table 4) are also 
% given here.
function_shock_A = @(shockm1, obst, obst1 ) filter_matrix_2_A\obst + final_filter_2_A * obst1 + final_filter_3_A * shockm1 ; 
function_shock_B = @(shockm1, obst, obst1 ) filter_matrix_2_B\obst + final_filter_2_B * obst1 + final_filter_3_B * shockm1 ; 
function_shock_D = @(shockm1, obst, obst1 ) filter_matrix_2_D\obst + final_filter_2_D * obst1 + final_filter_3_D * shockm1 ; 
filtered_shocks_A = zeros(length(data_sales_dt),industries);
filtered_shocks_B = zeros(length(data_sales_dt),industries);
filtered_shocks_D = zeros(length(data_sales_dt),industries);

for t_idx=2:size(data_sales_dt,1)
    filtered_shocks_A(t_idx,:)=function_shock_A(filtered_shocks_A(t_idx-1,:)',data_sales_dt(t_idx,:)',data_sales_dt(t_idx-1,:)');
    filtered_shocks_B(t_idx,:)=function_shock_B(filtered_shocks_B(t_idx-1,:)',data_sales_dt(t_idx,:)',data_sales_dt(t_idx-1,:)');
    filtered_shocks_D(t_idx,:)=function_shock_D(filtered_shocks_D(t_idx-1,:)',data_sales_dt(t_idx,:)',data_sales_dt(t_idx-1,:)');
end
 
matrix_eps_lag_A=-filter_matrix_2_A*final_filter_3_A;
matrix_data_lag_A=-filter_matrix_2_A*final_filter_2_A;
matrix_eps_A=filter_matrix_2_A;
productivity_shocks_kf_A=kfilter(data_sales_dt, matrix_data_lag_A, matrix_eps_A, matrix_eps_lag_A);

matrix_eps_lag_B=-filter_matrix_2_B*final_filter_3_B;
matrix_data_lag_B=-filter_matrix_2_B*final_filter_2_B;
matrix_eps_B=filter_matrix_2_B;
productivity_shocks_kf_B=kfilter(data_sales_dt, matrix_data_lag_B, matrix_eps_B, matrix_eps_lag_B);

matrix_eps_lag_D=-filter_matrix_2_D*final_filter_3_D;
matrix_data_lag_D=-filter_matrix_2_D*final_filter_2_D;
matrix_eps_D=filter_matrix_2_D;
productivity_shocks_kf_D=kfilter(data_sales_dt, matrix_data_lag_D, matrix_eps_D, matrix_eps_lag_D);

if max(abs(imag(filtered_shocks_A)))>5e-6
   error('imaginary filtered shocks');
end
filtered_shocks_A=filtered_shocks_A((burn_in+1):end,:);
filtered_shocks_B=filtered_shocks_B((burn_in+1):end,:);
filtered_shocks_D=filtered_shocks_D((burn_in+1):end,:);
filtered_shocks_A_kf=productivity_shocks_kf_A((burn_in+1):end,:);
filtered_shocks_B_kf=productivity_shocks_kf_B((burn_in+1):end,:);
filtered_shocks_D_kf=productivity_shocks_kf_D((burn_in+1):end,:);
optionsFactoran = optimset('TolFun',1e-14, 'TolX', 1e-14, 'MaxIter',5000');
% For the US data, to do the historical decompositions, we need to compute
% the F_t, the common factor in each periods. 
if data_set==1
     % This check determines whether we usethe  Equation (11) (or its analgoue)-based
     % filter or if we only do the Kalman Filter.
    if max(abs(eig(final_filter_3_A)))<1 && min(abs(eig(filter_matrix_1_A)))>.01
        [lambda_A, psi_A, T_A, stats_A, F_A]=factoran_(real(filtered_shocks_A),  1 , ...
        'Nobs' , size(filtered_shocks_A,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
       sigma_Matrix_A=lambda_A*lambda_A'+diag(psi_A);
       cov_model_output_A=filter_matrix_2_row_2_A*sigma_Matrix_A*filter_matrix_2_row_2_A';
       cov_ind_output_A=filter_matrix_2_row_2_A*diag(psi_A)*filter_matrix_2_row_2_A';
        for t_idx=0:25
             cov_model_output_A=cov_model_output_A+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*sigma_Matrix_A*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
             cov_ind_output_A=cov_ind_output_A+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*diag(psi_A)*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
        end
    end
    if max(abs(eig(final_filter_3_B)))<1 && min(abs(eig(filter_matrix_1_B)))>.01
         [lambda_B, psi_B, T_B, stats_B, F_B]=factoran_(real(filtered_shocks_B),  1 , ...
         'Nobs' , size(filtered_shocks_B,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
         sigma_Matrix_B=lambda_B*lambda_B'+diag(psi_B); 
         cov_model_output_B=filter_matrix_2_row_2_B*sigma_Matrix_B*filter_matrix_2_row_2_B';
         cov_ind_output_B=filter_matrix_2_row_2_B*diag(psi_B)*filter_matrix_2_row_2_B';
         for t_idx=0:25
             cov_model_output_B=cov_model_output_B+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,(1+industries):(2*industries))*sigma_Matrix_B*DR_State_Exo(:,(1+industries):(2*industries))'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
             cov_ind_output_B=cov_ind_output_B+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,(1+industries):(2*industries))*diag(psi_B)*DR_State_Exo(:,(1+industries):(2*industries))'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
         end
    end
    if max(abs(eig(final_filter_3_D)))<1 && min(abs(eig(filter_matrix_1_D)))>.01
         [lambda_D, psi_D, T_D, stats_D, F_D]=factoran_(real(filtered_shocks_D),  1 , ...
         'Nobs' , size(filtered_shocks_D,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
         sigma_Matrix_D=lambda_D*lambda_D'+diag(psi_D); 
         cov_model_output_D=filter_matrix_2_row_2_D*sigma_Matrix_D*filter_matrix_2_row_2_D';
         cov_ind_output_D=filter_matrix_2_row_2_D*diag(psi_D)*filter_matrix_2_row_2_D';
         for t_idx=0:25
             cov_model_output_D=cov_model_output_D+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*sigma_Matrix_D*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
             cov_ind_output_D=cov_ind_output_D+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*diag(psi_D)*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
         end
    end
    [lambda_A_kf, psi_A_kf, T_A_kf, stats_A_kf, F_A_kf]=factoran_(real(filtered_shocks_A_kf),  1 , ...
        'Nobs' , size(filtered_shocks_A_kf,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
    [lambda_B_kf, psi_B_kf, T_B_kf, stats_B_kf, F_B_kf]=factoran_(real(filtered_shocks_B_kf),  1 , ...
        'Nobs' , size(filtered_shocks_B_kf,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
    [lambda_D_kf, psi_D_kf, T_D_kf, stats_D_kf, F_D_kf]=factoran_(real(filtered_shocks_D_kf),  1 , ...
        'Nobs' , size(filtered_shocks_D_kf,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
% for the non-US, non-benchmark dataset, below, don't try to perform the analysis
% with government preference shocks.
else
    if max(abs(eig(final_filter_3_A)))<1 && min(abs(eig(filter_matrix_1_A)))>.01
        [lambda_A, psi_A, T_A, stats_A]=factoran_(cov(real(filtered_shocks_A)),  1 , ...
        'Xtype' ,'covariance',  'Nobs' , size(filtered_shocks_A,1)-1,   'Delta' , 1e-6, 'optimopts',optionsFactoran);
        sigma_Matrix_A=lambda_A*lambda_A'+diag(psi_A);
        cov_model_output_A=filter_matrix_2_row_2_A*sigma_Matrix_A*filter_matrix_2_row_2_A';
        cov_ind_output_A=filter_matrix_2_row_2_A*diag(psi_A)*filter_matrix_2_row_2_A';
        for t_idx=0:25
             cov_model_output_A=cov_model_output_A+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*sigma_Matrix_A*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
             cov_ind_output_A=cov_ind_output_A+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*diag(psi_A)*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
        end
    end
    if max(abs(eig(final_filter_3_B)))<1 && min(abs(eig(filter_matrix_1_B)))>.01
         [lambda_B, psi_B, T_B, stats_B]=factoran_(cov(real(filtered_shocks_B)),  1 , ...
          'Xtype' ,'covariance',  'Nobs' , size(filtered_shocks_B,1)-1,  'Delta' , 1e-6, 'optimopts',optionsFactoran);
          sigma_Matrix_B=lambda_B*lambda_B'+diag(psi_B); 
          cov_model_output_B=filter_matrix_2_row_2_B*sigma_Matrix_B*filter_matrix_2_row_2_B';
          cov_ind_output_B=filter_matrix_2_row_2_B*diag(psi_B)*filter_matrix_2_row_2_B';
          for t_idx=0:25
              cov_model_output_B=cov_model_output_B+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*sigma_Matrix_B*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
              cov_ind_output_B=cov_ind_output_B+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*diag(psi_B)*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
          end
    end
    [lambda_A_kf, psi_A_kf, T_A_kf, stats_A_kf]=factoran_(cov(real(filtered_shocks_A_kf)),  1 , ...
         'Xtype', 'covariance',  'Nobs' , size(filtered_shocks_A_kf,1)-1,  'Delta' , 1e-6, 'optimopts',optionsFactoran);
    [lambda_B_kf, psi_B_kf, T_B_kf, stats_B_kf]=factoran_(cov(real(filtered_shocks_B_kf)),  1 , ...
         'Xtype' , 'covariance',  'Nobs' , size(filtered_shocks_B_kf,1)-1, 'Delta' , 1e-6, 'optimopts',optionsFactoran);
end

 sigma_Matrix_A_kf=lambda_A_kf*lambda_A_kf'+diag(psi_A_kf);
 sigma_Matrix_B_kf=lambda_B_kf*lambda_B_kf'+diag(psi_B_kf);
 sigma_Matrix_D_kf=lambda_D_kf*lambda_D_kf'+diag(psi_D_kf);
 cov_model_output_A_kf=filter_matrix_2_row_2_A*sigma_Matrix_A_kf*filter_matrix_2_row_2_A';
 cov_ind_output_A_kf=filter_matrix_2_row_2_A*diag(psi_A_kf)*filter_matrix_2_row_2_A';
 cov_model_output_B_kf=filter_matrix_2_row_2_B*sigma_Matrix_B_kf*filter_matrix_2_row_2_B';
 cov_ind_output_B_kf=filter_matrix_2_row_2_B*diag(psi_B_kf)*filter_matrix_2_row_2_B';
 if data_set==1
     cov_model_output_D_kf=filter_matrix_2_row_2_D*sigma_Matrix_D_kf*filter_matrix_2_row_2_D';
     cov_ind_output_D_kf=filter_matrix_2_row_2_D*diag(psi_D_kf)*filter_matrix_2_row_2_D';
 end
 for t_idx=0:25   
     cov_model_output_A_kf=cov_model_output_A_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*sigma_Matrix_A_kf*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     cov_ind_output_A_kf=cov_ind_output_A_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,1:industries)*diag(psi_A_kf)*DR_State_Exo(:,1:industries)'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     cov_model_output_B_kf=cov_model_output_B_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,(1+industries):(2*industries))*sigma_Matrix_B_kf*DR_State_Exo(:,(1+industries):(2*industries))'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     cov_ind_output_B_kf=cov_ind_output_B_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,(1+industries):(2*industries))*diag(psi_B_kf)*DR_State_Exo(:,(1+industries):(2*industries))'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     if  data_set==1
     cov_model_output_D_kf=cov_model_output_D_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*sigma_Matrix_D_kf*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     cov_ind_output_D_kf=cov_ind_output_D_kf+filter_matrix_1_row_2*mpower(DR_State_State,t_idx)*DR_State_Exo(:,[1:industries-1 3*industries])*diag(psi_D_kf)*DR_State_Exo(:,[1:industries-1 3*industries])'*(mpower(DR_State_State,t_idx)')*filter_matrix_1_row_2';
     end
 end
 
 % For the baseline US datasets, compute the historical decomposition. 
 if data_set==1
     agg_shocks_A=cumsum([(lambda_A_kf*F_A_kf')' ]);
     ind_shocks_A=cumsum(filtered_shocks_A_kf)-agg_shocks_A;
     agg_shocks_B=cumsum([(lambda_B_kf*F_B_kf')' ]);
     ind_shocks_B=cumsum(filtered_shocks_B_kf)-agg_shocks_B;
     state_from_agg_shocks_A=zeros(size(filtered_shocks_A,1)+1,industries);
     state_from_ind_shocks_A=zeros(size(filtered_shocks_A,1)+1,industries);
     state_from_agg_shocks_B=zeros(size(filtered_shocks_B,1)+1,industries);
     state_from_ind_shocks_B=zeros(size(filtered_shocks_B,1)+1,industries);
     output_from_agg_shocks_A=zeros(size(filtered_shocks_A,1)+1,1);
     output_from_ind_shocks_A=zeros(size(filtered_shocks_A,1)+1,1);
     output_from_ind_shocks_A_all=zeros(size(filtered_shocks_A,1)+1,industries);
     output_from_agg_shocks_B=zeros(size(filtered_shocks_B,1)+1,1);
     output_from_ind_shocks_B=zeros(size(filtered_shocks_B,1)+1,1);
     output_from_ind_shocks_B_all=zeros(size(filtered_shocks_B,1)+1,industries);

     for t_idx=2:(size(filtered_shocks_A,1)+1)
       state_from_agg_shocks_A(t_idx,:)=(DR_State_State*state_from_agg_shocks_A(t_idx-1,:)'+DR_State_Exo(:,1:industries)*agg_shocks_A(t_idx-1,:)')';
       state_from_ind_shocks_A(t_idx,:)=(DR_State_State*state_from_ind_shocks_A(t_idx-1,:)'+DR_State_Exo(:,1:industries)*ind_shocks_A(t_idx-1,:)')';
       output_from_agg_shocks_A(t_idx)=filter_matrix_2_row_2_A*(agg_shocks_A(t_idx-1,:)')+(filter_matrix_1_row_2*state_from_agg_shocks_A(t_idx-1,:)');
       output_from_ind_shocks_A(t_idx)=filter_matrix_2_row_2_A*(ind_shocks_A(t_idx-1,:)')+(filter_matrix_1_row_2*state_from_ind_shocks_A(t_idx-1,:)');
       output_from_ind_shocks_A_all(t_idx,:)=(filter_matrix_2_row_1(:,1:industries)-diag(S_M)*(eps_Q-I_N)-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_Exo(:,1:industries))*(ind_shocks_A(t_idx-1,:)') + ... 
           ((filter_matrix_1_row_1-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_State)*state_from_ind_shocks_A(t_idx-1,:)');
       output_from_ind_shocks_A_all(t_idx,:)=(output_from_ind_shocks_A_all(t_idx,:).*S_Y);
       state_from_agg_shocks_B(t_idx,:)=(DR_State_State*state_from_agg_shocks_B(t_idx-1,:)'+DR_State_Exo(:,1+industries:2*industries)*agg_shocks_B(t_idx-1,:)')';
       state_from_ind_shocks_B(t_idx,:)=(DR_State_State*state_from_ind_shocks_B(t_idx-1,:)'+DR_State_Exo(:,1+industries:2*industries)*ind_shocks_B(t_idx-1,:)')';
       output_from_agg_shocks_B(t_idx)=filter_matrix_2_row_2_B*(agg_shocks_B(t_idx-1,:)')+(filter_matrix_1_row_2*state_from_agg_shocks_B(t_idx-1,:)');
       output_from_ind_shocks_B(t_idx)=filter_matrix_2_row_2_B*(ind_shocks_B(t_idx-1,:)')+(filter_matrix_1_row_2*state_from_ind_shocks_B(t_idx-1,:)');
       output_from_ind_shocks_B_all(t_idx,:)=(filter_matrix_2_row_1(:,1+industries:2*industries)-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_Exo(:,(1+industries):(2*industries)))*(ind_shocks_B(t_idx-1,:)') + ...
           ((filter_matrix_1_row_1-diag(S_M)*(eps_Q-I_N)*(I_N-S_1_M)*DR_Jump_State)*state_from_ind_shocks_B(t_idx-1,:)');
       output_from_ind_shocks_B_all(t_idx,:)=(output_from_ind_shocks_B_all(t_idx,:).*S_Y);
     end     
        if counter==71  %% this is the iteration for which eps_D=1 and eps_M=0.1 for the U.S. baseline dataset
            historical_decomposition(:,1)=(output_from_agg_shocks_A(2:end)-output_from_agg_shocks_A(1:end-1));
            historical_decomposition(:,2)=(output_from_ind_shocks_A(2:end)-output_from_ind_shocks_A(1:end-1));
            historical_decomposition_all_1=(output_from_ind_shocks_A_all(2:end,:)-output_from_ind_shocks_A_all(1:end-1,:));
        elseif counter==73 %% this is the iteration for which eps_D=1 and eps_M=1 for the U.S. baseline dataset
            historical_decomposition(:,3)=(output_from_agg_shocks_A(2:end)-output_from_agg_shocks_A(1:end-1));
            historical_decomposition(:,4)=(output_from_ind_shocks_A(2:end)-output_from_ind_shocks_A(1:end-1));
            historical_decomposition_all_2=(output_from_ind_shocks_A_all(2:end,:)-output_from_ind_shocks_A_all(1:end-1,:));
        elseif counter==146  %% this is the iteration for which eps_D=1 and eps_M=0.10 for the U.S. baseline dataset with goods durability = 0.4 for durable industries
            historical_decomposition(:,5)=(output_from_agg_shocks_A(2:end)-output_from_agg_shocks_A(1:end-1));  
            historical_decomposition(:,6)=(output_from_ind_shocks_A(2:end)-output_from_ind_shocks_A(1:end-1));
            historical_decomposition_all_3=(output_from_ind_shocks_A_all(2:end,:)-output_from_ind_shocks_A_all(1:end-1,:));
        end
 end
 
 % output the data to results table.
 results_table(counter,:)=[parameters, real([mean(mean(corr(filtered_shocks_A(:,1:industries)))) mean(mean(corr(filtered_shocks_B(:,1:industries))))  ...
  mean(mean(corr(filtered_shocks_A_kf(:,1:industries)))) mean(mean(corr(filtered_shocks_B_kf(:,1:industries)))) ...
   cov_ind_output_A/cov_model_output_A cov_ind_output_B/cov_model_output_B cov_ind_output_A_kf/cov_model_output_A_kf cov_ind_output_B_kf/cov_model_output_B_kf]), ...
  max(abs(eig(final_filter_3_A))), max(abs(eig(final_filter_3_B))) , min(abs(eig(filter_matrix_1_A))) , min(abs(eig(filter_matrix_1_B))), cov_ind_output_D/cov_model_output_D, cov_ind_output_D_kf/cov_model_output_D_kf,  mean(mean(corr(filtered_shocks_D(:,1:industries)))) mean(mean(corr(filtered_shocks_D_kf(:,1:industries))))];
  