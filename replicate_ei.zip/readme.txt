This folder contains the replication materials for the Economic Insights article, "How Accurate Are Long-Run Employment Projections?" There is a single do file that produces the figures and tables in this note: ei_analysis.do . 

If you have any questions, or notice any bugs, please feel free to contact me at atalayecon@gmail.com .
