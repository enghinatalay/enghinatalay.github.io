function f=mleVar(par)
diff= 0.00005;  
diff4=0.0005;
diff5=0.00005;

%% This paper computes the standard errors of the MLE estimates that are computed 
%% in Table 1 of the paper.  Before running this code, you must run mlemax.m

m0=par(1);
r0=par(2);
a0=par(3);
b0=par(4);

%% Don't really worry about the "fake" ones.  These are to compute the standard errors
%% of the simulated data Table D1 of the paper 

if m0==20 && r0==2 && b0==5
  AA=csvread('fake_mm20_rr_2_alpha_1_beta_5.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(1,:);
elseif m0==20 && r0==2 && b0==1
  AA=csvread('fake_mm20_rr_2_alpha_1_beta_1.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(2,:);
elseif m0==20 && r0==1 && b0==5
  AA=csvread('fake_mm20_rr_1_alpha_1_beta_5.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(3,:);
elseif m0==20 && r0==1 && b0==1
  AA=csvread('fake_mm20_rr_1_alpha_1_beta_1.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(4,:);
elseif m0==40 && r0==2 && b0==5
  AA=csvread('fake_mm40_rr_2_alpha_1_beta_5.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(5,:);
elseif m0==40 && r0==2 && b0==1
  AA=csvread('fake_mm40_rr_2_alpha_1_beta_1.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(6,:);
elseif m0==40 && r0==1 && b0==5
  AA=csvread('fake_mm40_rr_1_alpha_1_beta_5.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(7,:);
elseif m0==40 && r0==1 && b0==1
  AA=csvread('fake_mm40_rr_1_alpha_1_beta_1.csv');
  AA=AA(:,[3,1]);
  BB=csvread('mleresultsFakeTot.csv');
  BB=BB(8,:);
else 
  AA=csvread('formle.csv',1,0);  %% Read in the data 
  BB=csvread('mleresults.csv');  %% Read in the parameter estimates 
end

mJ=BB(1);
rJ=BB(2) ;

mJAt=BB(3);
rJAt=BB(4);

mJA=exp(mJAt-rJAt);
rJA=exp(rJAt);

m0=exp(BB(5));
r0=exp(BB(6));
b0=BB(8);
a0=b0*BB(7)/(1-BB(7));

diff6=.00003;
diff6=diff5;

%% This is the code used to compute the standard errors of the basic JR model.

mat2=zeros(2);
base=mlefunG([mJ, rJ],AA);
a11=mlefunG([mJ+diff6 rJ], AA);
a12=mlefunG([mJ-diff6 rJ], AA);
a13=mlefunG([mJ+2*diff6 rJ], AA);
a14=mlefunG([mJ-2*diff6 rJ], AA);
mat2(1,1)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff6^2);

a11=mlefunG([mJ rJ+diff6], AA);
a12=mlefunG([mJ rJ-diff6], AA);
a13=mlefunG([mJ rJ+2*diff6], AA);
a14=mlefunG([mJ rJ-2*diff6], AA);
mat2(2,2)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff6^2);

a1=mlefunG([mJ+diff6 rJ+diff6  ], AA);
a2=mlefunG([mJ+diff6 rJ-diff6  ], AA);
a3=mlefunG([mJ-diff6 rJ+diff6  ], AA);
a4=mlefunG([mJ-diff6 rJ-diff6 ], AA);
mat2(1,2)=(a1-a2-a3+a4)/4/diff6/diff6;
mat2(2,1)=mat2(1,2);

inv(mat2)

mat3=zeros(2);

diff2=rJA/1000;
diff3=mJA/1000;

%% This is the code that computes the standard errors for the 
%% middle column of Table 1.  You should get some warning 
%% from matlab about the near-singularity of the Information matrix.

base=mlefunR([log(mJA)+log(rJA), log(rJA)],AA);
a11=mlefunR([log(mJA+diff3)+log(rJA) log(rJA)], AA);
a12=mlefunR([log(mJA-diff3)+log(rJA) log(rJA)], AA);
a13=mlefunR([log(mJA+2*diff3)+log(rJA) log(rJA)], AA);
a14=mlefunR([log(mJA-2*diff3)+log(rJA) log(rJA)], AA);
mat3(1,1)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff3^2);

a11=mlefunR([log(mJA)+log(rJA+diff2) log(rJA+diff2)], AA);
a12=mlefunR([log(mJA)+log(rJA-diff2) log(rJA-diff2)], AA);
a13=mlefunR([log(mJA)+log(rJA+2*diff2) log(rJA+2*diff2)], AA);
a14=mlefunR([log(mJA)+log(rJA-2*diff2) log(rJA-2*diff2)], AA);
mat3(2,2)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff2^2);

a1=mlefunR([log(mJA+diff3)+log(diff2+rJA) log(rJA+diff2)  ], AA);
a2=mlefunR([log(mJA+diff3)+log(-diff2+rJA) log(rJA-diff2)  ], AA);
a3=mlefunR([log(mJA-diff3)+log(diff2+rJA) log(rJA+diff2)  ], AA);
a4=mlefunR([log(mJA-diff3)+log(-diff2+rJA) log(rJA-diff2) ], AA);
mat3(1,2)=(a1-a2-a3+a4)/4/diff3/diff2;
mat3(2,1)=mat3(1,2);

mat3(1,1)
mat3(1,2)
mat3(2,2)

mat3(2,2)*mat3(1,1)-mat3(1,2)*mat3(1,2)
  ff=eig(mat3)
  ff(1)
  ff(2)

mat1=zeros(4);

iter=0;
csvwrite('iter3.csv', iter)
%% This is the code to compute the standard errors of the extended Jackson-Rogers model.

base=mlefunpb([log(m0) log(r0) a0/(a0+b0) b0], AA, 3);

a11=mlefunpb([log(m0+diff4) log(r0)  a0/(a0+b0) b0], AA, 3);
a12=mlefunpb([log(m0-diff4) log(r0)  a0/(a0+b0) b0], AA, 3);
a13=mlefunpb([log(m0+2*diff4) log(r0)  a0/(a0+b0) b0], AA, 3);
a14=mlefunpb([log(m0-2*diff4) log(r0)  a0/(a0+b0) b0], AA, 3);
mat1(1,1)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff4^2);

a11=mlefunpb([log(m0) log(r0+diff)  a0/(a0+b0) b0], AA, 3);
a12=mlefunpb([log(m0) log(r0-diff)  a0/(a0+b0) b0], AA, 3);
a13=mlefunpb([log(m0) log(r0+2*diff)  a0/(a0+b0) b0], AA, 3);
a14=mlefunpb([log(m0) log(r0-2*diff)  a0/(a0+b0) b0], AA, 3);
mat1(2,2)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff^2);

a11=mlefunpb([log(m0) log(r0)  (a0+diff5)/(a0+diff5+b0) b0], AA, 3);
a12=mlefunpb([log(m0) log(r0)  (a0-diff5)/(a0-diff5+b0) b0], AA, 3);
a13=mlefunpb([log(m0) log(r0)  (a0+2*diff5)/(a0+2*diff5+b0) b0], AA, 3);
a14=mlefunpb([log(m0) log(r0)  (a0-2*diff5)/(a0-2*diff5+b0) b0], AA, 3);
mat1(3,3)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff5^2);

a11=mlefunpb([log(m0) log(r0)  a0/(a0+b0+diff4) b0+diff4], AA, 3);
a12=mlefunpb([log(m0) log(r0)  a0/(a0+b0-diff4) b0-diff4], AA, 3);
a13=mlefunpb([log(m0) log(r0)  a0/(a0+b0+2*diff4) b0+2*diff4], AA, 3);
a14=mlefunpb([log(m0) log(r0)  a0/(a0+b0-2*diff4) b0-2*diff4], AA, 3);
mat1(4,4)=(4/3*a11-5/2*base+4/3*a12-1/12*a13-1/12*a14)/(diff4^2);

a1=mlefunpb([log(m0+diff4) log(r0+diff)  a0/(a0+b0) b0], AA, 3);
a2=mlefunpb([log(m0+diff4) log(r0-diff)  a0/(a0+b0) b0], AA, 3);
a3=mlefunpb([log(m0-diff4) log(r0+diff)  a0/(a0+b0) b0], AA, 3);
a4=mlefunpb([log(m0-diff4) log(r0-diff)  a0/(a0+b0) b0], AA, 3);
mat1(1,2)=(a1-a2-a3+a4)/4/diff4/diff;
mat1(2,1)=mat1(1,2);

a1=mlefunpb([log(m0+diff4) log(r0)  (a0+diff5)/(a0+diff5+b0) b0], AA, 3);
a2=mlefunpb([log(m0+diff4) log(r0)  (a0-diff5)/(a0-diff5+b0) b0], AA, 3);
a3=mlefunpb([log(m0-diff4) log(r0)  (a0+diff5)/(a0+diff5+b0) b0], AA, 3);
a4=mlefunpb([log(m0-diff4) log(r0)  (a0-diff5)/(a0-diff5+b0) b0], AA, 3);
mat1(1,3)=(a1-a2-a3+a4)/4/diff4/diff5;
mat1(3,1)=mat1(1,3);

a1=mlefunpb([log(m0+diff4) log(r0)  (a0)/(a0+diff4+b0) (b0+diff4)], AA, 3);
a2=mlefunpb([log(m0+diff4) log(r0)  (a0)/(a0-diff4+b0) (b0-diff4)], AA, 3);
a3=mlefunpb([log(m0-diff4) log(r0)  (a0)/(a0+diff4+b0) (b0+diff4)], AA, 3);
a4=mlefunpb([log(m0-diff4) log(r0)  (a0)/(a0-diff4+b0) (b0-diff4)], AA, 3);
mat1(1,4)=(a1-a2-a3+a4)/4/diff4/diff4;
mat1(4,1)=mat1(1,4);

a1=mlefunpb([log(m0) log(r0+diff)  (a0+diff5)/(a0+diff5+b0) b0], AA, 3);
a2=mlefunpb([log(m0) log(r0+diff)  (a0-diff5)/(a0-diff5+b0) b0], AA, 3);
a3=mlefunpb([log(m0) log(r0-diff)  (a0+diff5)/(a0+diff5+b0) b0], AA, 3);
a4=mlefunpb([log(m0) log(r0-diff)  (a0-diff5)/(a0-diff5+b0) b0], AA, 3);
mat1(2,3)=(a1-a2-a3+a4)/4/diff/diff5;
mat1(3,2)=mat1(2,3);

a1=mlefunpb([log(m0) log(r0+diff)  (a0)/(a0+diff4+b0) (b0+diff4)], AA, 3);
a2=mlefunpb([log(m0) log(r0+diff)  (a0)/(a0-diff4+b0) (b0-diff4)], AA, 3);
a3=mlefunpb([log(m0) log(r0-diff)  (a0)/(a0+diff4+b0) (b0+diff4)], AA, 3);
a4=mlefunpb([log(m0) log(r0-diff)  (a0)/(a0-diff4+b0) (b0-diff4)], AA, 3);
mat1(2,4)=(a1-a2-a3+a4)/4/diff/diff4;
mat1(4,2)=mat1(2,4);

a1=mlefunpb([log(m0) log(r0)  (a0+diff5)/(a0+diff4+diff5+b0) (b0+diff4)], AA, 3);
a2=mlefunpb([log(m0) log(r0)  (a0+diff5)/(a0+diff5-diff4+b0) (b0-diff4)], AA, 3);
a3=mlefunpb([log(m0) log(r0)  (a0-diff5)/(a0+diff4-diff5+b0) (b0+diff4)], AA, 3);
a4=mlefunpb([log(m0) log(r0)  (a0-diff5)/(a0-diff4-diff5+b0) (b0-diff4)], AA, 3);
mat1(3,4)=(a1-a2-a3+a4)/4/diff5/diff4;
mat1(4,3)=mat1(3,4);

mat1(1,1)
mat1(2,1)
mat1(3,1)
mat1(4,1)
mat1(2,2)
mat1(2,3)
mat1(2,4)
mat1(3,3)
mat1(3,4)
mat1(4,4)

%% Invert each of the matrices.  Again, matlab should spit out a warning about the second matrix being near-singular.

mat1=inv(mat1)
mat2=inv(mat2);
mat3=inv(mat3);

f=[sqrt(mat2(1,1)) sqrt(mat2(2,2))  sqrt(mat3(1,1)) sqrt(mat3(2,2)) sqrt(mat1(1,1)) sqrt(mat1(2,2)) sqrt(mat1(3,3)) sqrt(mat1(4,4))]
 
