function f=mlefunpb(par, A,num)

%% This piece of code is called by anneal.m 
%% During each iteration mlefunpb computes the 
%% log-likelihood of the extended Jackson-Rogers model

m=par(1);
r=par(2);
aRatb=par(3);  
b=par(4);
a=b*aRatb/(1-aRatb);  

if num==1
  iter=csvread('iter1.csv');
  iter=iter+1;
  csvwrite('iter1.csv', iter);
elseif num==2
  iter=csvread('iter2.csv');
  iter=iter+1;
  csvwrite('iter2.csv', iter);
elseif num==3
  iter=csvread('iter3.csv');
  iter=iter+1;
  csvwrite('iter3.csv', iter);
elseif num==4
  iter=csvread('iter4.csv');
  iter=iter+1;
  csvwrite('iter4.csv', iter);
else
  iter=csvread('iter5.csv');
  iter=iter+1;
  csvwrite('iter5.csv', iter);
end

if mod(iter,1)==0
  pbar=pbarfun([exp(m) exp(r) a b],num);
  if num==1
  csvwrite('pbar1.csv', pbar);
  elseif num==2
  csvwrite('pbar2.csv', pbar);
  elseif num==3
  csvwrite('pbar3.csv', pbar);
  elseif num==4
  csvwrite('pbar4.csv', pbar);
  else 
  csvwrite('pbar5.csv', pbar);
  end

else 
  if num==1 
    pbar=csvread('pbar1.csv');
  elseif num==2
    pbar=csvread('pbar2.csv');
  elseif num==3
    pbar=csvread('pbar3.csv');
  elseif num==4
    pbar=csvread('pbar4.csv');
  else 
    pbar=csvread('pbar5.csv');
  end
end

bins=5e3;  %% Bins is the number of possible values of p 

combos=unique(A, 'rows');
combos=[combos zeros(length(combos),1)];
for it=1:length(combos)
  combos(it,3)=sum(A(:,1)==combos(it,1) & A(:,2)==combos(it,2));
end

prob=zeros(length(combos),1);
for it=1:length(combos)
  qq=combos(it,1); 
  aa=combos(it,2);
  xy=(1:(bins))/bins-1/2/bins;
  aq=sum(exp(-log(bins)+qq*log(1-aa.^(xy/pbar/(1+exp(r))))+(a-1)*log(xy)+(b-1)*log(1-xy)+(exp(m+r)*xy/(1+exp(r)))*log(aa)));  %% See equation 14 of the paper.
  prob(it)=(log(aq)+gammaln(pbar*exp(m+r)+qq)-gammaln(pbar*exp(m+r))-gammaln(qq+1)+gammaln(a+b)-gammaln(a)-gammaln(b));
end

rrrr=clock;
tim=rrrr(4)+rrrr(5)/60+rrrr(6)/60/60;
[iter/100 tim pbar m  r a b  sum(prob.*combos(:,3))/1e3]
f=-sum(prob.*combos(:,3));
