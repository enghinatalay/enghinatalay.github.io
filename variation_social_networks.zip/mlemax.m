A=csvread('formle.csv',1,0);
A1=zeros(1,8);
iter=0
csvwrite('iter5.csv',iter);

A1(1,1:2)=fminsearch(@(par) mlefunG(par, A), [15,.5]);  % first column 
A1(1,3:4)=fminsearch(@(par) mlefunR(par, A), [1,-50]);  % second column 
[x1 x2]=annealSm([6.0285,0.0653,.047,6.544],A,5);  % third column
A1(1,5:8)=x1;
csvwrite('mleresults.csv', A1)
exit


