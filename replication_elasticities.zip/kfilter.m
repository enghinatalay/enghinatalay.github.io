function [productivity_shocks_kf] = kfilter(sales_data, matrix_y_lag, matrix_eps, matrix_eps_lag )

% suppose we have written delta_y= X_1* delta_y_{t-1} + X_2*eps+X_3*eps{t-1}
% then matrix_y_lag=X_1, matrix_eps=X_2 and matrix_eps_lag=X_3 . 

% first re-write the VARMA(1,1) model in state-space form, as in page 168 of
% DeJong/Dave or page 214 of Canova

industries=size(sales_data,2);
D_1=[ matrix_y_lag, eye(industries); zeros(industries,2*industries) ];    
D_2=[ matrix_eps ; matrix_eps_lag ];   
x1=[eye(industries), zeros(industries)]';  
% kf initialization
alpha_previous=[0*sales_data(1,:)'; zeros(industries,1)];
omega_previous=eye(2*industries)*100;
error_t=zeros(2*industries,size(sales_data,1));  %% Matrix to store the errors
% filtering steps
for t_idx=1:size(sales_data,1)  
   predict_variance=x1'*omega_previous*x1;
   forecast_error=sales_data(t_idx,:)'-x1'*alpha_previous;
   update_mean=alpha_previous+omega_previous*x1*(predict_variance\forecast_error);
   update_variance=omega_previous-omega_previous*x1*(predict_variance\(x1'))*omega_previous;
   alpha_previous=D_1*update_mean ;
   error_t(1:industries, t_idx)=matrix_eps\forecast_error;  
   omega_previous=D_1*update_variance*D_1'+D_2*D_2';
end
productivity_shocks_kf=error_t(1:industries,:)';







